#Author: Barbora Kessel
#Affiliation: Helmholtz Centre for Infection Research, Braunschweig, Germany
#E-mail: barbora.kessel@helmholtz-hzi.de
#Last update: 2022-02-23 
#################################

#this code creates plots showing the different results from NHANES studies
#and from application of different tests for the  blood sample analysis

#required libraries
library(forestplot)
library(binom)

#study codes from the reference list 
aux<-read.csv("code_book.csv")
refs<-as.matrix(aux[,2])
row.names(refs)<-aux[,1]

#read in data
dat<-read.csv("overview_forest.csv")

#create link between abbreviations and full name of population subgroups
dict<-cbind(c("Blood donors","Ethnic groups","Viral hepatitis","Children",
              "Pregnant women","Immunodeficiency","Exposed","Occupational group",
              "Ethnic groups","Rural","General population","Pig related exposure","Immunodef./Children"))
row.names(dict)<-c("BD","EG","VH","C","PW","I","EP","OG","EG/GP","R","GP","PRE","I/C")

#remove all not analysed, i.e. analysed.in.group=="-"
wh<-which(dat$analysed.in.group=="-")
dat<-dat[-wh,]

#remove doubly analysed samples
dupl<-data.frame(author=c("Alvarado","Engle","Pujol"),
                 category=c("R","BD","PW"))
ind_out<-NULL
for (i in 1: nrow(dupl)){
  wh<-which(dat$research.group==dupl$author[i] & 
              dat$analysed.in.group==dupl$category[i] &
              dat$overlap==1)
  ind_out<-c(ind_out,wh)
}
dat<-dat[-ind_out,]

#NHANES plot
wh<-which(grepl("NHANES",dat$comment))
nhanes<-dat[wh,]
#order IgM, IgG
wh1<-which(nhanes$param=="IgM")
wh2<-which(nhanes$param=="IgG")
nhanes<-nhanes[c(wh1,wh2),]
nhanes[,c("overlap","research.group","param","comment")]
nhanes<-nhanes[c(1:5,5+c(1,2,10,3,4,6,5,7,9,8,11)),]
nhanes[,c("overlap","research.group","param","comment")]

#plot NHANES duplicates
indB<-5
nn<-nrow(nhanes)
tabletext <- cbind(
  c( "Details","IgM",nhanes$comment[1:indB],"IgG",nhanes$comment[(indB+1):nn]),
  c("p","",paste(nhanes$p[1:indB]*100,"%"),"",paste(nhanes$p[(indB+1):nn]*100,"%")),
  c( "95% CI","", paste("[",nhanes$lo[1:indB]*100,"%, ",nhanes$up[1:indB]*100,"%]"),
     "",paste("[",nhanes$lo[(indB+1):nn]*100,"%, ",nhanes$up[(indB+1):nn]*100,"%]")),
  c("Ref.","", refs[nhanes$paper[1:indB],1],"",refs[nhanes$paper[(indB+1):nn],1]),
  c("Test","",nhanes$test[1:indB],"",nhanes$test[(indB+1):nn]))


box_spec<-c(list(gpar(fill="black")),
            list(gpar(fill="black")))
for(i in 1: nrow(nhanes)){
  if (nhanes[i,"overlap"]==1){
    box_spec<-c(box_spec,list(gpar(fill="gray")))
  }else{
    box_spec<-c(box_spec,list(gpar(fill="black")))
  }
 if (i==indB) {
   box_spec<-c(box_spec,list(gpar(fill="gray")))
 }
}
styles<-fpShapesGp(
  box=box_spec
)

tiff(filename="nhanes.tiff",width=14*300,height=10*300,res=300,compression="lzw")
forestplot(tabletext, 
           graph.pos = 4,
           mean=c(NA,NA,nhanes$p[1:indB],NA,nhanes$p[(indB+1):nn])*100,
           lower=c(NA,NA,nhanes$lo[1:indB],NA,nhanes$lo[(indB+1):nn])*100,
           upper=c(NA,NA,nhanes$up[1:indB],NA,nhanes$up[(indB+1):nn])*100,
           is.summary = c(TRUE,TRUE, rep(FALSE,indB),TRUE,rep(FALSE,nn-indB)),
           txt_gp = fpTxtGp(label = list(gpar(fontfamily = "",cex=1.5),
                                         gpar(fontfamily = "",cex=1.5)),
                            ticks = gpar(fontfamily = "", cex = 1.5),
                            xlab  = gpar(fontfamily = "", cex = 1.5),
                            legend = gpar(fontfamily = "", cex = 1.5)),
           col=fpColors(lines="darkgray",zero="darkgray"),
           clip = c(0,25), 
           colgap=unit(0.02,"npc"),
           lwd.ci=c(2),
           lwd.zero=2,
           lty.ci=c(1),
           boxsize=0.45,
           xticks=seq(0,25,by=5),
           xlab="Percentage of positive results [%]",
           graphwidth=unit(10,"cm"),
           title="General population, USA, NHANES",
           shapes_gp=styles
)
dev.off()

#plot repeated tests
wh<-which(dat$overlap==1 & !grepl("NHANES",dat$comment))

aux<-dat[wh,c("research.group","param","analysed.in.group")]
wh1<-which(duplicated(aux))
aux<-aux[-wh1,]

aix<-sort(aux$param,index.return=T)
aux<-aux[aix$ix,]

ind<-NULL
for(i in 1: nrow(aux)){
  wh<-which(dat$research.group==aux$research.group[i] &
              dat$param==aux$param[i] &
              dat$analysed.in.group==aux$analysed.in.group[i])
  ind<-c(ind,wh)
}

testD<-dat[ind,]

testD$mean<-testD$n.i/testD$n*100
aux<-binom.agresti.coull(testD$n.i, testD$n)
testD$lower<-pmax(0,aux$lower*100)
testD$upper<-pmin(100,aux$upper*100)

part1<-which(testD$param=="IgG")
part2<-which(testD$param=="IgM")
part3<-which(testD$param=="Tanti")

testD$catText<-dict[testD$analysed.in.group,1]

tabletext <- cbind(
  c( "Category","IgG",testD$catText[part1],"IgM",testD$catText[part2],
     "Total anti-HEV",testD$catText[part3]),
  c("p","",paste(round(testD$mean[part1],digits=1),"%"),"",
    paste(round(testD$mean[part2],digits=1),"%"),"",
    paste(round(testD$mean[part3],digits=1),"%")),
  c( "n_i/n", "",paste(round(testD$n.i[part1]),"/",round(testD$n[part1])),
     "",paste(round(testD$n.i[part2]),"/",round(testD$n[part2])),
     "",paste(round(testD$n.i[part3]),"/",round(testD$n[part3]))),
  c("Ref.","",refs[testD$paper[part1],1],"",refs[testD$paper[part2],1],
    "",refs[testD$paper[part3],1]),
  c("Country","", testD$country[part1],"",testD$country[part2],
    "",testD$country[part3]),
  c("Test","",testD$test[part1],"",testD$test[part2],
   "",testD$test[part3]))

box_spec<-c(list(gpar(fill="black")),
            list(gpar(fill="black")))
for(i in 1: nrow(testD)){
  if (testD[i,"overlap"]==1){
    box_spec<-c(box_spec,list(gpar(fill="gray")))
  }else{
    box_spec<-c(box_spec,list(gpar(fill="black")))
  }
  if (i==length(part1) | i==(length(part1)+length(part2))) {
    box_spec<-c(box_spec,list(gpar(fill="gray")))
  }
}
styles<-fpShapesGp(
  box=box_spec
)

tiff(filename="double_tests.tiff",width=20*300,height=15*300,res=300,compression="lzw")
forestplot(tabletext, 
           graph.pos = 4,
           mean=c(NA,NA,testD$mean[part1],NA,testD$mean[part2],NA,testD$mean[part3]),
           lower=c(NA,NA,testD$lower[part1],NA,testD$lower[part2],NA,testD$lower[part3]),
           upper=c(NA,NA,testD$upper[part1],NA,testD$upper[part2],NA,testD$upper[part3]),
           is.summary = c(TRUE,TRUE, rep(FALSE,length(part1)),TRUE,rep(FALSE,length(part2)),
                          TRUE, rep(FALSE,length(part3))),
           txt_gp = fpTxtGp(label = list(gpar(fontfamily = "",cex=1.8),
                                         gpar(fontfamily = "",cex=1.8)),
                            ticks = gpar(fontfamily = "", cex = 1.5),
                            xlab  = gpar(fontfamily = "", cex = 1.5),
                            legend = gpar(fontfamily = "", cex = 1.5)),
           col=fpColors(lines="darkgray",zero="darkgray"),
           clip = c(0,25), 
           colgap=unit(0.02,"npc"),
           lwd.ci=c(3),
           lwd.zero=2,
           lty.ci=c(1),
           boxsize=0.45,
           xticks=seq(0,40,by=5),
           xlab="Percentage of positive results [%]",
           graphwidth=unit(13,"cm"),
           title="Multiple tests used on the same sample",
           hrzl_lines=list("5"=gpar(lty=2,lwd=2,col="black"),
                           "7"=gpar(lty=2,lwd=2,col="black"),
                           "9"=gpar(lty=2,lwd=2,col="black"),
                           "11"=gpar(lty=2,lwd=2,col="black"),
                           "13"=gpar(lty=2,lwd=2,col="black"),
                           "15"=gpar(lty=2,lwd=2,col="black"),
                           "17"=gpar(lty=2,lwd=2,col="black"),
                           "19"=gpar(lty=2,lwd=2,col="black"),
                           "21"=gpar(lty=2,lwd=2,col="black"),
                           "24"=gpar(lty=2,lwd=2,col="black"),
                           "26"=gpar(lty=2,lwd=2,col="black"),
                           "28"=gpar(lty=2,lwd=2,col="black"),
                           "31"=gpar(lty=2,lwd=2,col="black")),
           
           shapes_gp=styles
)
dev.off()
