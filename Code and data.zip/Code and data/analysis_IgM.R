#Author: Barbora Kessel
#Affiliation: Helmholtz Centre for Infection Research, Braunschweig, Germany
#E-mail: barbora.kessel@helmholtz-hzi.de
#Last update: 2022-02-24 
#################################

#this code yields results about IgM positivity

#used libraries
library(forestplot)
library(binom)
library(meta)

#read in code book for assigning the correct reference number to each study, consistent
#with the Reference List in the Supplementary material

aux<-read.csv("code_book.csv")
refs<-as.matrix(aux[,2])
row.names(refs)<-aux[,1]

#read in the data
dat<-read.csv("overview_forest.csv")

#assign region to each study
dat$region<-"Central America"
dat$region[dat$country=="USA" | 
             dat$country=="Canada" |
             dat$country=="Greenland" |
             dat$country=="Mexico" |
             grepl("USA",dat$country)]<-"North America"
dat$region[dat$country=="Chile" | 
             dat$country=="Argentina" |
             dat$country=="Brazil" |
             dat$country=="Bolivia" | 
             dat$country=="Colombia" |
             dat$country=="Peru" |
             dat$country=="Venezuela" | 
             dat$country=="Uruguay" |
             dat$country=="French Guiana"]<-"South America"

#check that no country was forgotten (i.e. Central America contains correct countries)
unique(dat$country[dat$region=="Central America"])

#create a connection between abbreviations and long names for subgroups
dict<-cbind(c("Blood donors","Ethnic groups","Viral hepatitis","Children",
              "Pregnant women","Immunodeficiency","Exposed","Occupational group",
              "Ethnic groups","Rural","General population","Pig related exposure",
              "Immunodef./Children","Combined"))
row.names(dict)<-c("BD","EG","VH","C","PW","I","EP","OG","EG/GP","R","GP","PRE","I/C","M")

###########################IgM##############
igm<-dat[grepl("IgM",dat$param) & !grepl("[+]",dat$param) &
           !grepl("RNA",dat$param) & !grepl("IgG",dat$param),]

#exclude nhanes duplicates
wh<-which(grepl("NHANES",igm$comment) & igm$overlap==1)
igm<-igm[-wh,]


#calculate fictive sample size and number of positives for
#NHANES results
#standard error on the log-scale
igm$se<-(log(igm$up)-log(igm$lo))/2/qnorm(0.975)
wh<-which(is.na(igm$n))
igm$n[wh]<-round((1/igm$p[wh]+1/(1-igm$p[wh]))/(igm$se[wh]^2),digits=1)
igm$n.i[wh]<-round(igm$p[wh]*igm$n[wh],digits=1)

#comparison of the intervals obtained from the fictive sample sizes and 
#fictive numbers of popsitive on the logit scale and the originally reported
#confidence intervals and seroprevalences in the studies
round(binom.logit(igm$n.i[wh],igm$n[wh])[,4:6],digits=3)
igm[wh,c("p","lo","up")]

#calculate Agresti-Coull confidence intervals in % and truncate to the permissible range
#0-100% if necessary
igm$mean<-igm$n.i/igm$n*100
wh<-which(!is.na(igm$mean))
aux<-binom.agresti.coull(igm$n.i[wh], igm$n[wh])
igm$lower[wh]<-pmax(0,aux$lower*100)
igm$upper[wh]<-pmin(100,aux$upper*100)


aux<-sort(igm$analysed.in.group,index.return=T)
igm<-igm[aux$ix,]

#sort according to country within categories
aux<-unique(igm$analysed.in.group)
for(i in 1: length(aux)){
  wh<-which(igm$analysed.in.group==aux[i])
  aa<-sort(igm$country[wh],index.return=T)
  igm[wh,]<-igm[wh[aa$ix],]
}


#create the following order of the population subgroups (for plotting)
order1<-c("BD","GP","EG","R","PW","OG","I/C","I","VH")
#a simple check that no subgroup was left out in the list above
if (any(is.na(match(igm$analysed.in.group,order1)))){
  print(paste("Subgroup left out:"))
  print(unique(igm$analysed.in.group[is.na(match(igm$analysed.in.group,order1))]))
}else{
  print("OK")
}

#reorder as desired (according to order1)  
ind<-NULL
for (i in 1: length(order1)){
  ind<-c(ind,which(igm$analysed.in.group==order1[i]))
}
igm<-igm[ind,]

#pooling all but viral hepatitis
sel<-which(igm$overlap==0 & igm$analysed.in.group!="VH")

#I/C should be considered within I group
igm$analysed.in.group0<-igm$analysed.in.group
igm$analysed.in.group0[igm$analysed.in.group=="I/C"]<-"I"

res<-metaprop(event=round(n.i),n=round(n),data=igm[sel,],
              sm="PLOGIT",method="glmm",hakn=T)


sel<-which(igm$overlap==0  &
             (igm$analysed.in.group0=="I" |
                igm$analysed.in.group0=="BD"))

res<-metaprop(event=round(n.i),n=round(n),data=igm[sel,],subgroup=analysed.in.group0,
              sm="PLOGIT",method="glmm",hakn=T)

whBD<-which(res$bylevs=="BD")
mBD<-100/(1+exp(-res$TE.random.w[whBD]))
loBD<-100/(1+exp(-res$lower.random.w[whBD]))
upBD<-100/(1+exp(-res$upper.random.w[whBD]))
lineBD<-paste("95% CI: [",round(100/(1+exp(-res$lower.random.w[whBD])),digits=1) ,"%, ",
              round(100/(1+exp(-res$upper.random.w[whBD])),digits=1) ,"%], I2=",
              (round(res$I2.w[whBD]*100)),"%, ",
              "tau2=",(round(res$tau2.w[whBD],digits=2)),sep="")
whI<-which(res$bylevs=="I")
mI<-100/(1+exp(-res$TE.random.w[whI]))
loI<-100/(1+exp(-res$lower.random.w[whI]))
upI<-100/(1+exp(-res$upper.random.w[whI]))
lineI<-paste("95% CI: [",round(100/(1+exp(-res$lower.random.w[whI])),digits=1) ,"%, ",
             round(100/(1+exp(-res$upper.random.w[whI])),digits=1) ,"%], I2=",
             (round(res$I2.w[whI]*100)),"%, ",
             "tau2=",(round(res$tau2.w[whI],digits=2)),sep="")

#comparing VH and the rest
sel<-which(igm$overlap==0 & igm$mean<90)
res0<-metaprop(event=round(n.i),n=round(n),data=igm[sel,],
               subgroup=(igm$analysed.in.group[sel]=="VH"),
               sm="PLOGIT",method="glmm",hakn=T)

whVH<-which(res0$bylevs==TRUE)
mVH<-100/(1+exp(-res0$TE.random.w[whVH]))
loVH<-100/(1+exp(-res0$lower.random.w[whVH]))
upVH<-100/(1+exp(-res0$upper.random.w[whVH]))
lineVH<-paste("95% CI: [",round(100/(1+exp(-res0$lower.random.w[whVH])),digits=1) ,"%, ",
              round(100/(1+exp(-res0$upper.random.w[whVH])),digits=1) ,"%], I2=",
              (round(res0$I2.w[whVH]*100)),"%, ",
              "tau2=",(round(res0$tau2.w[whVH],digits=2)),sep="")


sel<-which(igm$analysed.in.group!="VH" & igm$overlap==0)

igm$catText<-dict[igm$analysed.in.group,1]

part1<-which(igm$analysed.in.group0[sel]=="BD")
part2<-(1:length(sel))[-c(part1)]
tabletext <- cbind(
  c( "Category",igm$catText[sel[part1]],
     "Random effects GLMM",
     igm$catText[sel[part2]],
     "Random effects GLMM"),
  c("p",paste(round(igm$mean[sel[part1]],digits=1),"%"),
    paste(round(mBD,digits=1),"%"),
    paste(round(igm$mean[sel[part2]],digits=1),"%"),
    paste(round(mI,digits=1),"%")),
  c( "n_i/n",paste(igm$n.i[sel[part1]],"/",igm$n[sel[part1]]),
     "", paste(igm$n.i[sel[part2]],"/",igm$n[sel[part2]]),""),
  c("Ref.",refs[igm$paper[sel[part1]],1],
    "",refs[igm$paper[sel[part2]],1],""),
  c("Country",igm$country[sel[part1]],
    "",igm$country[sel[part2]],""),
  c( "Details",igm$details[sel[part1]],
     lineBD,igm$details[sel[part2]],lineI),
  c( "Test",igm$test[sel[part1]],"",igm$test[sel[part2]],""))


tiff(filename="igm_pooling.tiff",width=22.5*300,height=11.5*300,res=300,compression="lzw")
forestplot(tabletext, 
           graph.pos = 4,
           mean=c(NA,igm$mean[sel[part1]],
                  mBD,
                  igm$mean[sel[part2]],
                  mI),
           lower=c(NA,igm$lower[sel[part1]],
                   loBD,
                   igm$lower[sel[part2]],
                   loI),
           upper=c(NA,igm$upper[sel[part1]],
                   upBD,
                   igm$upper[sel[part2]],
                   upI),
           is.summary = c(TRUE,rep(FALSE,nrow(igm[sel[part1],])),
                          TRUE,rep(FALSE,nrow(igm[sel[part2],])),TRUE),
           txt_gp = fpTxtGp(label = list(gpar(fontfamily = "",cex=1.8),
                                         gpar(fontfamily = "",cex=1.8)),
                            ticks = gpar(fontfamily = "", cex = 1.8),
                            xlab  = gpar(fontfamily = "", cex = 1.8),
                            legend = gpar(fontfamily = "", cex = 1.8),
                            summary = gpar(fontfamily = "", cex = 1.8)),
           col=fpColors(lines="darkgray",zero="darkgray"),
           clip = c(0,15), 
           colgap=unit(0.01,"npc"),
           lwd.ci=c(3),
           lwd.zero=2,
           lty.ci=c(1),
           boxsize=0.45,
           xticks=seq(0,15,by=2),
           xlab="Percentage of IgM positive results [%]",
           graphwidth=unit(10,"cm"),
           title="IgM",
           hrzl_lines=list("8"=gpar(lty=2,lwd=2,col="black"),
                           "10"=gpar(lty=2,lwd=2,col="black"),
                           "12"=gpar(lty=2,lwd=2,col="black"),
                           "13"=gpar(lty=2,lwd=2,col="black"),
                           "15"=gpar(lty=2,lwd=2,col="black"),
                           "16"=gpar(lty=2,lwd=2,col="black"))
        
)
dev.off()


#sensitivity analysis
#blood donors,pooled estimate non-VH, comparison with VH

#list alternative results
whaut_gr<-igm[igm$overlap==1,c("research.group","analysed.in.group","test")]

#create data frame for collecting the results, after exchanging one result per time
sensres<-data.frame(category=NULL,
                    n=NULL,
                    p=NULL,
                    lower=NULL,
                    upper=NULL,
                    I2=NULL,
                    tau2=NULL,
                    pval=NULL
)
k<-1
for(i in 1: nrow(whaut_gr)){
  if (whaut_gr[i,2]=="BD"){
    aux<-igm[igm$analysed.in.group=="BD",]
    wh<-which(aux$research.group==whaut_gr[i,1] & 
                aux$analysed.in.group==whaut_gr[i,2]& aux$overlap==0)
    aux<-aux[-wh,]
    aux[aux$research.group==whaut_gr[i,1] &
          aux$analysed.in.group==whaut_gr[i,2] &
          aux$test==whaut_gr[i,3],"overlap"]<-0
    res1<-metaprop(event=round(n.i),n=round(n),data=aux[aux$overlap==0,],
                   sm="PLOGIT",method="glmm",hakn=T)
    sensres[k,"category"]<-"BD"
    sensres[k,"n"]<-res1$k
    sensres[k,"p"]<-100/(1+exp(-res1$TE.random))
    sensres[k,"lower"]<-100/(1+exp(-res1$lower.random))
    sensres[k,"upper"]<-100/(1+exp(-res1$upper.random))
    sensres[k,"I2"]<-round(res1$I2*100)
    sensres[k,"tau2"]<-round(res1$tau2,digits=2)
    k<-k+1
  }
  aux<-igm[igm$mean<90,]
  wh<-which(aux$research.group==whaut_gr[i,1] & 
              aux$analysed.in.group==whaut_gr[i,2]& aux$overlap==0)
  aux<-aux[-wh,]
  aux[aux$research.group==whaut_gr[i,1] &
        aux$analysed.in.group==whaut_gr[i,2] &
        aux$test==whaut_gr[i,3],"overlap"]<-0
  res1<-metaprop(event=round(n.i),n=round(n),data=aux[aux$overlap==0,],
                 subgroup =(analysed.in.group=="VH"),
                 sm="PLOGIT",method="glmm",hakn=T)
  sensres[k,"category"]<-"non-VH"
  wh1<-which(res1$bylevs==FALSE)
  sensres[k,"n"]<-res1$k.w[wh1]
  sensres[k,"p"]<-100/(1+exp(-res1$TE.random.w[wh1]))
  sensres[k,"lower"]<-100/(1+exp(-res1$lower.random.w[wh1]))
  sensres[k,"upper"]<-100/(1+exp(-res1$upper.random.w[wh1]))
  sensres[k,"I2"]<-round(res1$I2.w[wh1]*100)
  sensres[k,"tau2"]<-round(res1$tau2.w[wh1],digits=2)
  sensres[k,"pval"]<-summary(res1)$pval.Q.b.random
  k<-k+1
}
sensres

#all at once, 2 possibilities, non-VH vs VH
whaut_gr0<-whaut_gr[-2,] # -1,or  -2 keep only one result from Zafrullah at a time
aux<-igm[igm$mean<90,]
wh<-NULL
for (j in 1: nrow(whaut_gr0)){
  wh<-c(wh,which(aux$research.group==whaut_gr0[j,1] & 
                   aux$analysed.in.group==whaut_gr0[j,2]& aux$overlap==0))
}
aux<-aux[-wh,]
for (j in 1: nrow(whaut_gr0)){
  aux$overlap[aux$research.group==whaut_gr0[j,1] & 
                aux$analysed.in.group==whaut_gr0[j,2]& 
                aux$test==whaut_gr0[j,3]& aux$overlap==1]<-0
}
res1<-metaprop(event=round(n.i),n=round(n),data=aux[aux$overlap==0,],
               subgroup=(analysed.in.group=="VH"),
               sm="PLOGIT",method="glmm",hakn=T)
res1


#viral hep, no pooling
sel<-which(igm$analysed.in.group=="VH")
tabletext <- cbind(
  c("Country",igm$country[sel]),
  c("p",paste(round(igm$mean[sel],digits=1),"%")),
  c( "n_i/n",paste(igm$n.i[sel],"/",igm$n[sel])),
  c("Ref.",refs[igm$paper[sel],1]),
  c( "Details",igm$details[sel]),
  c("Test",igm$test[sel]))


tiff(filename="igmVH.tiff",width=17*300,height=6*300,res=300,compression="lzw")
forestplot(tabletext, 
           graph.pos = 4,
           mean=c(NA,igm$mean[sel]),
           lower=c(NA,igm$lower[sel]),
           upper=c(NA,igm$upper[sel]),
           is.summary = c(TRUE,rep(FALSE,nrow(igm[sel,]))),
           txt_gp = fpTxtGp(label = list(gpar(fontfamily = "",cex=1.5),
                                         gpar(fontfamily = "",cex=1.5)),
                            ticks = gpar(fontfamily = "", cex = 1.5),
                            xlab  = gpar(fontfamily = "", cex = 1.5),
                            legend = gpar(fontfamily = "", cex = 1.5)),
           col=fpColors(lines="darkgray",zero="darkgray"),
           clip = c(0,100), 
           colgap=unit(0.01,"npc"),
           lwd.ci=c(3),
           lwd.zero=2,
           lty.ci=c(1),
           boxsize=0.45,
           xticks=seq(0,100,by=10),
           xlab="Percentage of IgM positive results [%]",
           graphwidth=unit(10,"cm"),
           title="IgM in viral hepatitis",
           hrzl_lines=list("6"=gpar(lty=2,lwd=2,col="black"),
                           "8"=gpar(lty=2,lwd=2,col="black"),
                           "10"=gpar(lty=2,lwd=2,col="black"),
                           "13"=gpar(lty=2,lwd=2,col="black")),
           
)
dev.off()

#overview
median(igm$mean[igm$overlap==0 & igm$analysed.in.group!="VH"])
range(igm$mean[igm$overlap==0 & igm$analysed.in.group!="VH"])
length(unique(igm$paper[igm$overlap==0 & igm$analysed.in.group!="VH"]))
length((igm$paper[igm$overlap==0 & igm$analysed.in.group!="VH"]))

median(igm$mean[igm$overlap==0 & igm$analysed.in.group=="VH"])
range(igm$mean[igm$overlap==0 & igm$analysed.in.group=="VH"])
length(unique(igm$paper[igm$overlap==0 & igm$analysed.in.group=="VH"]))
length((igm$paper[igm$overlap==0 & igm$analysed.in.group=="VH"]))


#country-wise, 
igmC<-igm

aux<-sort(igmC$country,index.return=T)
igmC<-igmC[aux$ix,]

#sort according to category within country
aux<-unique(igmC$country)
for(i in 1: length(aux)){
  wh<-which(igmC$country==aux[i])
  aa<-sort(igmC$analysed.in.group[wh],index.return=T)
  igmC[wh,]<-igmC[wh[aa$ix],]
}

#with pooling
sel<-which(igmC$analysed.in.group!="VH" & (igmC$region=="South America" |
                                             igmC$region=="North America") & 
             igmC$overlap==0)
res<-metaprop(event=round(n.i),n=round(n),data=igmC[sel,],subgroup=region,
              sm="PLOGIT",method="glmm",hakn=T)

whSA<-which(res$bylevs=="South America")
lineSA<-paste("95% CI: [",round(100/(1+exp(-res$lower.random.w[whSA])),digits=1) ,"%, ",
              round(100/(1+exp(-res$upper.random.w[whSA])),digits=1) ,"%], I2=",
              (round(res$I2.w[whSA]*100)),"%, ",
              "tau2=",(round(res$tau2.w[whSA],digits=2)),sep="")
whNA<-which(res$bylevs=="North America")
lineNA<-paste("95% CI: [",round(100/(1+exp(-res$lower.random.w[whNA])),digits=1) ,"%, ",
              round(100/(1+exp(-res$upper.random.w[whNA])),digits=1) ,"%], I2=",
              (round(res$I2.w[whNA]*100)),"%, ",
              "tau2=",(round(res$tau2.w[whNA],digits=2)),sep="")

tabletext <- cbind(
  c( "Country",igmC$country[sel],"South America","North America"),
  c("p",paste(round(igmC$mean[sel],digits=1),"%"),
    paste(round(1/(1+exp(-res$TE.random.w[whSA]))*100,digits=1),"%"),
    paste(round(1/(1+exp(-res$TE.random.w[whNA]))*100,digits=1),"%")),
  c( "n_i/n", paste(igmC$n.i[sel],"/",igmC$n[sel]),"",""),
  c("Ref.",refs[igmC$paper[sel],1],"",""),
  c("Details",igmC$catText[sel],
    lineSA,lineNA),
  c("Test",igmC$test[sel],"","")
)

#plot 
tiff(filename="igmC_pooling.tiff",width=20*300,height=9*300,res=300,compression="lzw")
forestplot(tabletext, 
           graph.pos = 4,
           mean=c(NA,igmC$mean[sel],100/(1+exp(-res$TE.random.w[whSA])),
                  100/(1+exp(-res$TE.random.w[whNA]))),
           lower=c(NA,igmC$lower[sel],100/(1+exp(-res$lower.random.w[whSA])),
                   100/(1+exp(-res$lower.random.w[whNA]))),
           upper=c(NA,igmC$upper[sel],100/(1+exp(-res$upper.random.w[whSA])),
                   100/(1+exp(-res$upper.random.w[whNA]))),
           is.summary = c(TRUE,rep(FALSE,nrow(igmC[sel,])),TRUE,TRUE),
           txt_gp = fpTxtGp(label = list(gpar(fontfamily = "",cex=1.5),
                                         gpar(fontfamily = "",cex=1.5)),
                            ticks = gpar(fontfamily = "", cex = 1.5),
                            xlab  = gpar(fontfamily = "", cex = 1.5),
                            legend = gpar(fontfamily = "", cex = 1.5),
                            summary = gpar(fontfamily="",cex=1.5)),
           col=fpColors(lines="darkgray",zero="darkgray"),
           clip = c(0,14), 
           colgap=unit(0.02,"npc"),
           lwd.ci=c(3),
           lwd.zero=2,
           lty.ci=c(1),
           boxsize=0.45,
           xticks=seq(0,14,by=2),
           xlab="Percentage of IgM positive results [%]",
           graphwidth=unit(10,"cm"),
           title="IgM",
           hrzl_lines=list("11"=gpar(lty=3,lwd=2,col="black"),
                           "24"=gpar(lty=3,lwd=2,col="black"))
)
dev.off()


###################IgM+############################
#select IgM+ results
igmplus<-dat[grepl("IgM",dat$param) & grepl("[+]",dat$param) &
               !grepl("RNA",dat$param),]

#calculate seroprevalence and Agresti-Coull 95% confidence intervals,
#all in %, truncated to 0-100%
igmplus$mean<-igmplus$n.i/igmplus$n*100
aux<-binom.agresti.coull(igmplus$n.i, igmplus$n)
igmplus$lower<-pmax(0,aux$lower*100)
igmplus$upper<-pmin(100,aux$upper*100)

aux<-sort(igmplus$analysed.in.group,index.return=T)
igmplus<-igmplus[aux$ix,]

#sort according to country within categories
aux<-unique(igmplus$analysed.in.group)
for(i in 1: length(aux)){
  wh<-which(igmplus$analysed.in.group==aux[i])
  aa<-sort(igmplus$country[wh],index.return=T)
  igmplus[wh,]<-igmplus[wh[aa$ix],]
}

#create the following order for plotting
order1<-c("BD","GP","PW","EG","M","C","OG","PRE","EP","I","VH")
#a simple check that no subgroup was left out in the list above
if (any(is.na(match(igmplus$analysed.in.group,order1)))){
  print(paste("Subgroup left out:"))
  print(unique(igmplus$analysed.in.group[is.na(match(igmplus$analysed.in.group,order1))]))
}else{
  print("OK")
}

#reorder as wanted
ind<-NULL
for (i in 1: length(order1)){
  ind<-c(ind,which(igmplus$analysed.in.group==order1[i]))
}
igmplus<-igmplus[ind,]

igmplus$catText<-dict[igmplus$analysed.in.group,1]

#erase results for sample size<10
igmplus$mean1<-igmplus$mean
igmplus$mean1[igmplus$n<10]<-NA
igmplus$lower1<-igmplus$lower
igmplus$lower1[igmplus$n<10]<-NA
igmplus$upper1<-igmplus$upper
igmplus$upper1[igmplus$n<10]<-NA
#pooling
sel<-which(igmplus$n>=10 & igmplus$overlap==0)
res<-metaprop(event=n.i,n=n,data=igmplus[sel,],
              sm="PLOGIT",method="glmm",hakn=T)


sel<-which(igmplus$n>=10 & (igmplus$analysed.in.group=="BD" |
                              igmplus$analysed.in.group=="VH"  ))
res0<-metaprop(event=n.i,n=n,data=igmplus[sel,],subgroup=analysed.in.group,
              sm="PLOGIT",method="glmm",hakn=T)

wh<-which(res0$bylevs=="BD")
mBD<-100/(1+exp(-res0$TE.random.w[wh]))
loBD<-100/(1+exp(-res0$lower.random.w[wh]))
upBD<-100/(1+exp(-res0$upper.random.w[wh]))
lineBD<-paste("95% CI: [",round(100/(1+exp(-res0$lower.random.w[wh])),digits=1) ,"%, ",
              round(100/(1+exp(-res0$upper.random.w[wh])),digits=1) ,"%], I2=",
              (round(res0$I2.w[wh]*100)),"%, ",
              "tau2=",(round(res0$tau2.w[wh],digits=2)),sep="")
wh<-which(res0$bylevs=="VH")
mVH<-100/(1+exp(-res0$TE.random.w[wh]))
loVH<-100/(1+exp(-res0$lower.random.w[wh]))
upVH<-100/(1+exp(-res0$upper.random.w[wh]))
lineVH<-paste("95% CI: [",round(100/(1+exp(-res0$lower.random.w[wh])),digits=1) ,"%, ",
              round(100/(1+exp(-res0$upper.random.w[wh])),digits=1) ,"%], I2=",
              (round(res0$I2.w[wh]*100)),"%, ",
              "tau2=",(round(res0$tau2.w[wh],digits=2)),sep="")

part1<-which(igmplus$analysed.in.group=="BD")
part3<-which(igmplus$analysed.in.group=="VH")
part2<-(1:nrow(igmplus))[-c(part1,part3)]
tabletext <- cbind(
 c( "Category",igmplus$catText[part1],
    "Random effects GLMM",igmplus$catText[part2],
    "No pooling done",igmplus$catText[part3],
    "Random effects GLMM"),
 c("p",paste(round(igmplus$mean[part1],digits=1),"%"),
   paste(round(mBD,digits=1),"%"),
   paste(round(igmplus$mean[part2],digits=1),"%"),
   "",paste(round(igmplus$mean[part3],digits=1),"%"),
   paste(round(mVH),"%")),
 c( "n_i/n", paste(igmplus$n.i[part1],"/",igmplus$n[part1]),
    "",paste(igmplus$n.i[part2],"/",igmplus$n[part2]),
    "",paste(igmplus$n.i[part3],"/",igmplus$n[part3]),""),
 c("Ref.",refs[igmplus$paper[part1],1],
   "",refs[igmplus$paper[part2],1],
   "",refs[igmplus$paper[part3],1],""),
 c("Country",igmplus$country[part1],"",igmplus$country[part2],"",
   igmplus$country[part3],""),
 c( "Details",igmplus$details[part1],lineBD,igmplus$details[part2],
    "",igmplus$details[part3],lineVH))


tiff(filename="igmplus_pooling.tiff",width=17*300,height=12.5*300,res=300,compression="lzw")
forestplot(tabletext, 
           graph.pos = 4,
           mean=c(NA,igmplus$mean1[part1],mBD,igmplus$mean1[part2],NA,
                  igmplus$mean1[part3],mVH),
           lower=c(NA,igmplus$lower1[part1],loBD,igmplus$lower1[part2],NA,
                   igmplus$lower1[part3],loVH),
           upper=c(NA,igmplus$upper1[part1],upBD,igmplus$upper1[part2],NA,
                   igmplus$upper1[part3],upVH),
          is.summary = c(TRUE,rep(FALSE,length(part1)),TRUE,rep(FALSE,length(part2)), 
                          TRUE, rep(FALSE,length(part3)),TRUE),
           txt_gp = fpTxtGp(label = list(gpar(fontfamily = "",cex=1.5),
                                         gpar(fontfamily = "",cex=1.5)),
                            ticks = gpar(fontfamily = "", cex = 1.5),
                            xlab  = gpar(fontfamily = "", cex = 1.5),
                            legend = gpar(fontfamily = "", cex = 1.5),
                            summary = gpar(fontfamily="",cex=1.5)),
           col=fpColors(lines="darkgray",zero="darkgray"),
           clip = c(0,100), 
           colgap=unit(0.02,"npc"),
           lwd.ci=c(3),
           lwd.zero=2,
           lty.ci=c(1),
           boxsize=0.45,
           xticks=seq(0,80,by=10),
           xlab="Percentage of IgM positive results [%]",
           graphwidth=unit(10,"cm"),
           title="IgM in positive samples",
           hrzl_lines=list("9"=gpar(lty=2,lwd=2,col="black"),
                          "11"=gpar(lty=2,lwd=2,col="black"),
                          "12"=gpar(lty=2,lwd=2,col="black"),
                          "14"=gpar(lty=2,lwd=2,col="black"),
                          "15"=gpar(lty=2,lwd=2,col="black"),
                          "16"=gpar(lty=2,lwd=2,col="black"),
                          "18"=gpar(lty=2,lwd=2,col="black"),
                          "19"=gpar(lty=2,lwd=2,col="black"),
                          "22"=gpar(lty=2,lwd=2,col="black"),
                          "31"=gpar(lty=2,lwd=2,col="black"))
  )
dev.off()

range(igmplus$mean)
median(igmplus$mean)

range(igmplus$mean1,na.rm=T)
median(igmplus$mean1,na.rm=T)

length(unique(igmplus$paper))
length((igmplus$paper))

#country-wise, 
igmplusC<-igmplus

aggregate(igmplusC$paper,list(igmplusC$country),FUN=function(x){length(unique(x))})
aggregate(igmplusC$paper,list(igmplusC$region),FUN=function(x){length(unique(x))})


aux<-sort(igmplusC$country,index.return=T)
igmplusC<-igmplusC[aux$ix,]

#sort according to category within country
aux<-unique(igmplusC$country)
for(i in 1: length(aux)){
  wh<-which(igmplusC$country==aux[i])
  aa<-sort(igmplusC$analysed.in.group[wh],index.return=T)
  igmplusC[wh,]<-igmplusC[wh[aa$ix],]
}

#create tis particular order for plotting
order1<-c("Argentina","Chile","Uruguay","Brazil","Colombia","Peru","Venezuela",
          "Cuba","USA","Canada")
#a simple check that no subgroup was left out in the list above
if (any(is.na(match(igmplusC$country,order1)))){
  print(paste("Country left out:"))
  print(unique(igmplusC$country[is.na(match(igmplusC$country,order1))]))
}else{
  print("OK")
}

ind<-NULL
for (i in 1: length(order1)){
  ind<-c(ind,which(igmplusC$country==order1[i]))
}
igmplusC<-igmplusC[ind,]

#plot with pooling
sel<-which(igmplusC$n>=10 & (igmplusC$region=="South America" |
                               igmplusC$region=="North America"))
res<-metaprop(event=n.i,n=n,data=igmplusC[sel,],subgroup=region,
              sm="PLOGIT",method="glmm",hakn=T)

whSA<-which(res$bylevs=="South America")
lineSA<-paste("95% CI: [",round(100/(1+exp(-res$lower.random.w[whSA])),digits=1) ,"%, ",
              round(100/(1+exp(-res$upper.random.w[whSA])),digits=1) ,"%], I2=",
              (round(res$I2.w[whSA]*100)),"%, ",
              "tau2=",(round(res$tau2.w[whSA],digits=2)),sep="")
whNA<-which(res$bylevs=="North America")
lineNA<-paste("95% CI: [",round(100/(1+exp(-res$lower.random.w[whNA])),digits=1) ,"%, ",
              round(100/(1+exp(-res$upper.random.w[whNA])),digits=1) ,"%], I2=",
              (round(res$I2.w[whNA]*100)),"%, ",
              "tau2=",(round(res$tau2.w[whNA],digits=2)),sep="")

tabletext <- cbind(
  c( "Country",igmplusC$country[sel],"South America","North America"),
  c("p",paste(round(igmplusC$mean[sel],digits=1),"%"),
    paste(round(1/(1+exp(-res$TE.random.w[whSA]))*100,digits=1),"%"),
    paste(round(1/(1+exp(-res$TE.random.w[whNA]))*100,digits=1),"%")),
  c( "n_i/n", paste(igmplusC$n.i[sel],"/",igmplusC$n[sel]),"",""),
  c("Ref.",refs[igmplusC$paper[sel],1],"",""),
  c("Details",dict[igmplusC$analysed.in.group[sel],1],
  lineSA,lineNA
  ))

#plot with pooling
tiff(filename="igmplusC_pooling.tiff",width=16*300,height=8.5*300,res=300,compression="lzw")
forestplot(tabletext, 
           graph.pos = 4,
           mean=c(NA,igmplusC$mean1[sel],100/(1+exp(-res$TE.random.w[whSA])),
                  100/(1+exp(-res$TE.random.w[whNA]))),
           lower=c(NA,igmplusC$lower1[sel],100/(1+exp(-res$lower.random.w[whSA])),
                   100/(1+exp(-res$lower.random.w[whNA]))),
           upper=c(NA,igmplusC$upper1[sel],100/(1+exp(-res$upper.random.w[whSA])),
                   100/(1+exp(-res$upper.random.w[whNA]))),
           is.summary = c(TRUE,rep(FALSE,nrow(igmplusC[sel,])),TRUE,TRUE),
           txt_gp = fpTxtGp(label = list(gpar(fontfamily = "",cex=1.5),
                                         gpar(fontfamily = "",cex=1.5)),
                            ticks = gpar(fontfamily = "", cex = 1.5),
                            xlab  = gpar(fontfamily = "", cex = 1.5),
                            legend = gpar(fontfamily = "", cex = 1.5),
                            summary = gpar(fontfamily="",cex=1.5)),
           col=fpColors(lines="darkgray",zero="darkgray"),
           clip = c(0,80), 
           colgap=unit(0.02,"npc"),
           lwd.ci=c(3),
           lwd.zero=2,
           lty.ci=c(1),
           boxsize=0.45,
           xticks=seq(0,80,by=10),
           xlab="Percentage of IgM positive results [%]",
           graphwidth=unit(10,"cm"),
           title="IgM in positive samples",
           hrzl_lines=list("19"=gpar(lty=3,lwd=2,col="black"),
                           "26"=gpar(lty=3,lwd=2,col="black"))
           
)
dev.off()



