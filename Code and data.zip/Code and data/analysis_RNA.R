#Author: Barbora Kessel
#Affiliation: Helmholtz Centre for Infection Research, Braunschweig, Germany
#E-mail: barbora.kessel@helmholtz-hzi.de
#Last update: 2022-02-24 
#################################

#this code yields results about RNA positivity

#used libraries
library(forestplot)
library(binom)
library(meta)

#read in code book for assigning the correct reference number to each study, consistent
#with the Reference List in the Supplementary material

aux<-read.csv("code_book.csv")
refs<-as.matrix(aux[,2])
row.names(refs)<-aux[,1]

#read in the data
dat<-read.csv("overview_forest.csv")

#assign region to each study
dat$region<-"Central America"
dat$region[dat$country=="USA" | 
             dat$country=="Canada" |
             dat$country=="Greenland" |
             dat$country=="Mexico" |
             grepl("USA",dat$country)]<-"North America"
dat$region[dat$country=="Chile" | 
             dat$country=="Argentina" |
             dat$country=="Brazil" |
             dat$country=="Bolivia" | 
             dat$country=="Colombia" |
             dat$country=="Peru" |
             dat$country=="Venezuela" | 
             dat$country=="Uruguay" |
             dat$country=="French Guiana"]<-"South America"

#check that no country was forgotten (i.e. Central America contains correct countries)
unique(dat$country[dat$region=="Central America"])

#create a connection between abbreviations and long names for subgroups
dict<-cbind(c("Blood donors","Ethnic groups","Viral hepatitis","Children",
              "Pregnant women","Immunodeficiency","Exposed","Occupational group",
              "Ethnic groups","Rural","General population","Pig related exposure",
              "Immunodef./Children","Combined"))
row.names(dict)<-c("BD","EG","VH","C","PW","I","EP","OG","EG/GP","R","GP","PRE","I/C","M")

#######################RNA########################
#select RNA results
rna<-dat[grepl("RNA",dat$param) & !grepl("[+]",dat$param),]

#calculate Agresti-Coull confidence intervals and seroprevalences, all in %
# and truncated to 0-100%
rna$mean<-rna$n.i/rna$n*100
aux<-binom.agresti.coull(rna$n.i, rna$n)
rna$lower<-pmax(0,aux$lower*100)
rna$upper<-pmin(100,aux$upper*100)

aux<-sort(rna$analysed.in.group,index.return=T)
rna<-rna[aux$ix,]

#sort according to country within categories
aux<-unique(rna$analysed.in.group)
for(i in 1: length(aux)){
  wh<-which(rna$analysed.in.group==aux[i])
  aa<-sort(rna$country[wh],index.return=T)
  rna[wh,]<-rna[wh[aa$ix],]
}


#create order for plotting
order1<-c("BD","M","R","EG","VH","I/C","I")
#a simple check that no subgroup was left out in the list above
if (any(is.na(match(rna$analysed.in.group,order1)))){
  print(paste("Subgroup left out:"))
  print(unique(rna$analysed.in.group[is.na(match(rna$analysed.in.group,order1))]))
}else{
  print("OK")
}
#reorder as desired
ind<-NULL
for (i in 1: length(order1)){
  ind<-c(ind,which(rna$analysed.in.group==order1[i]))
}
rna<-rna[ind,]

tabletext <- cbind(
  c( "Category",dict[rna$analysed.in.group,1]),
  c("p",paste(round(rna$mean,digits=1),"%")),
  c( "n_i/n", paste(rna$n.i,"/",rna$n)),
  c("Ref.",refs[rna$paper,1]),
  c("Country",rna$country),
  c( "Details",rna$details))


tiff(filename="rna.tiff",width=17*300,height=10*300,res=300,compression="lzw")
forestplot(tabletext, 
           graph.pos = 4,
           mean=c(NA,rna$mean),
           lower=c(NA,rna$lower),
           upper=c(NA,rna$upper),
           is.summary = c(TRUE,rep(FALSE,nrow(rna))),
           txt_gp = fpTxtGp(label = list(gpar(fontfamily = "",cex=1.5),
                                         gpar(fontfamily = "",cex=1.5)),
                            ticks = gpar(fontfamily = "", cex = 1.5),
                            xlab  = gpar(fontfamily = "", cex = 1.5),
                            legend = gpar(fontfamily = "", cex = 1.5)),
           col=fpColors(lines="darkgray",zero="darkgray"),
           clip = c(0,60), 
           colgap=unit(0.02,"npc"),
           lwd.ci=c(3),
           lwd.zero=2,
           lty.ci=c(1),
           boxsize=0.45,
           xticks=seq(0,60,by=10),
           xlab="Percentage of positive RNA results [%]",
           graphwidth=unit(10,"cm"),
           title="RNA in the total sample",
           hrzl_lines=list("5"=gpar(lty=2,lwd=2,col="black"),
                           "6"=gpar(lty=2,lwd=2,col="black"),
                           "7"=gpar(lty=2,lwd=2,col="black"),
                           "8"=gpar(lty=2,lwd=2,col="black"),
                           "10"=gpar(lty=2,lwd=2,col="black"))
           )
dev.off()

#median and range
range(rna$mean)
median(rna$mean)
#number of studies and results
length(unique(rna$paper))
length(rna$paper)

##########RNA+#################
#select RNA+
rnaplus<-dat[grepl("RNA",dat$param) & grepl("[+]",dat$param),]

#calculate seroprevalence and Agresti-Coull confidence intervals
#all in %, truncated to 0-100%
rnaplus$mean<-rnaplus$n.i/rnaplus$n*100
aux<-binom.agresti.coull(rnaplus$n.i, rnaplus$n)
rnaplus$lower<-pmax(0,aux$lower*100)
rnaplus$upper<-pmin(100,aux$upper*100)

aux<-sort(rnaplus$analysed.in.group,index.return=T)
rnaplus<-rnaplus[aux$ix,]

#sort according to country within categories
aux<-unique(rnaplus$analysed.in.group)
for(i in 1: length(aux)){
  wh<-which(rnaplus$analysed.in.group==aux[i])
  aa<-sort(rnaplus$country[wh],index.return=T)
  rnaplus[wh,]<-rnaplus[wh[aa$ix],]
}

#erase results based on sample size<10
rnaplus$mean1<-rnaplus$mean
rnaplus$mean1[rnaplus$n<10]<-NA
rnaplus$lower1<-rnaplus$lower
rnaplus$lower1[rnaplus$n<10]<-NA
rnaplus$upper1<-rnaplus$upper
rnaplus$upper1[rnaplus$n<10]<-NA

#create order for plotting
order1<-c("BD","PW","EG","M","OG","EP","I","VH")
#a simple check that no subgroup was left out in the list above
if (any(is.na(match(rnaplus$analysed.in.group,order1)))){
  print(paste("Subgroup left out:"))
  print(unique(rnaplus$analysed.in.group[is.na(match(rnaplus$analysed.in.group,order1))]))
}else{
  print("OK")
}

#reorder as desired
ind<-NULL
for (i in 1: length(order1)){
  ind<-c(ind,which(rnaplus$analysed.in.group==order1[i]))
}
rnaplus<-rnaplus[ind,]

tabletext <- cbind(
  c( "Category",dict[rnaplus$analysed.in.group,1]),
  c("p",paste(round(rnaplus$mean,digits=1),"%")),
  c( "n_i/n", paste(rnaplus$n.i,"/",rnaplus$n)),
  c("Ref.",refs[rnaplus$paper,1]),
  c("Country",rnaplus$country),
  c( "Details",rnaplus$details))


tiff(filename="rnaplus.tiff",width=17*300,height=10*300,res=300,compression="lzw")
forestplot(tabletext, 
           graph.pos = 4,
           mean=c(NA,rnaplus$mean1),
           lower=c(NA,rnaplus$lower1),
           upper=c(NA,rnaplus$upper1),
           is.summary = c(TRUE,rep(FALSE,nrow(rnaplus))),
           txt_gp = fpTxtGp(label = list(gpar(fontfamily = "",cex=1.5),
                                         gpar(fontfamily = "",cex=1.5)),
                            ticks = gpar(fontfamily = "", cex = 1.5),
                            xlab  = gpar(fontfamily = "", cex = 1.5),
                            legend = gpar(fontfamily = "", cex = 1.5)),
           col=fpColors(lines="darkgray",zero="darkgray"),
           clip = c(0,100), 
           colgap=unit(0.02,"npc"),
           lwd.ci=c(3),
           lwd.zero=2,
           lty.ci=c(1),
           boxsize=0.45,
           xticks=seq(0,80,by=10),
           xlab="Percentage of positive RNA results [%]",
           graphwidth=unit(10,"cm"),
           title="RNA in positive samples",
           hrzl_lines=list("8"=gpar(lty=2,lwd=2,col="black"),
                           "11"=gpar(lty=2,lwd=2,col="black"),
                           "13"=gpar(lty=2,lwd=2,col="black"),
                           "14"=gpar(lty=2,lwd=2,col="black"),
                           "16"=gpar(lty=2,lwd=2,col="black"),
                           "17"=gpar(lty=2,lwd=2,col="black"),
                           "19"=gpar(lty=2,lwd=2,col="black"))
           
)
dev.off()

#median and range
median(rnaplus$mean)
range(rnaplus$mean)
#median and range for sample size >=10
median(rnaplus$mean1,na.rm=T)
range(rnaplus$mean1,na.rm=T)
#number of results and studies
length(rnaplus$paper)
length(unique(rnaplus$paper))

