#Author: Barbora Kessel
#Affiliation: Helmholtz Centre for Infection Research, Braunschweig, Germany
#E-mail: barbora.kessel@helmholtz-hzi.de
#Last update: 2022-02-24 
#################################

#this code yields results about IgG positivity

#used libraries
library(forestplot)
library(binom)
library(meta)

#read in code book for assigning the correct reference number to each study, consistent
#with the Reference List in the Supplementary material

aux<-read.csv("code_book.csv")
refs<-as.matrix(aux[,2])
row.names(refs)<-aux[,1]

#read in the data
dat<-read.csv("overview_forest.csv")

#assign region to each study
dat$region<-"Central America"
dat$region[dat$country=="USA" | 
             dat$country=="Canada" |
             dat$country=="Greenland" |
             dat$country=="Mexico" |
             grepl("USA",dat$country)]<-"North America"
dat$region[dat$country=="Chile" | 
             dat$country=="Argentina" |
             dat$country=="Brazil" |
             dat$country=="Bolivia" | 
             dat$country=="Colombia" |
             dat$country=="Peru" |
             dat$country=="Venezuela" | 
             dat$country=="Uruguay" |
             dat$country=="French Guiana"]<-"South America"

#check that no country was forgotten (i.e. Central America contains correct countries)
unique(dat$country[dat$region=="Central America"])

#create a connection between abbreviations and long names for subgroups
dict<-cbind(c("Blood donors","Ethnic groups","Viral hepatitis","Children",
              "Pregnant women","Immunodeficiency","Exposed","Occupational group",
              "Ethnic groups","Rural","General population","Pig related exposure",
              "Immunodef./Children"))
row.names(dict)<-c("BD","EG","VH","C","PW","I","EP","OG","EG/GP","R","GP","PRE","I/C")


#select only entries from all data that relate to IgG
igg<-dat[grepl("IgG",dat$param) & !grepl("[+]",dat$param)
         & !grepl("IgM",dat$param),]

#exclude nhanes duplicates
wh<-which(grepl("NHANES",igg$comment) & igg$overlap==1)
igg<-igg[-wh,]

#exclude repeatedly analysed samples (subsamples)
dupl<-data.frame(author=c("Alvarado","Engle","Pujol"),
                 category=c("R","BD","PW"))
ind_out<-NULL
for (i in 1: nrow(dupl)){
  wh<-which(igg$research.group==dupl$author[i] & 
              igg$analysed.in.group==dupl$category[i] &
              igg$overlap==1)
  ind_out<-c(ind_out,wh)
}
igg<-igg[-ind_out,]

#calculate fictive sample size and number of positives for
#NHANES results
#standard error on the log-scale
igg$se<-(log(igg$up)-log(igg$lo))/2/qnorm(0.975)
wh<-which(is.na(igg$n))
igg$n[wh]<-round((1/igg$p[wh]+1/(1-igg$p[wh]))/(igg$se[wh]^2),digits=1)
igg$n.i[wh]<-round(igg$p[wh]*igg$n[wh],digits=1)

#comparison of the intervals obtained from the fictive sample sizes and 
#fictive numbers of popsitive on the logit scale and the originally reported
#confidence intervals and seroprevalences in the studies
round(binom.logit(igg$n.i[wh],igg$n[wh])[,4:6],digits=3)
igg[wh,c("p","lo","up")]

#calculate Agresti-Coull confidence intervals in % and truncate to the permissible range
#0-100% if necessary
igg$mean<-igg$n.i/igg$n*100
aux<-binom.agresti.coull(igg$n.i, igg$n)
igg$lower<-pmax(0,aux$lower*100)
igg$upper<-pmin(100,aux$upper*100)

#sort according to subpopulations
aux<-sort(igg$analysed.in.group,index.return=T)
igg<-igg[aux$ix,]


#sort according to country within subpopulations
aux<-unique(igg$analysed.in.group)
for(i in 1: length(aux)){
  wh<-which(igg$analysed.in.group==aux[i])
  aa<-sort(igg$country[wh],index.return=T)
  igg[wh,]<-igg[wh[aa$ix],]
}

#blood donors with pooling
sel<-which(igg$overlap!=1 &
             igg$analysed.in.group=="BD")

igg0<-igg[sel,]
#sort according to region
wh1<-which(igg0$region=="South America")
wh2<-which(igg0$region=="Central America")
wh3<-which(igg0$region=="North America")
igg0<-igg0[c(wh1,wh2,wh3),]

res<-metaprop(event=round(n.i),n=round(n),data=igg0,#subgroup=region,
              sm="PLOGIT",method="glmm",hakn=T)
mBD<-100/(1+exp(-res$TE.random))
loBD<-100/(1+exp(-res$lower.random))
upBD<-100/(1+exp(-res$upper.random))
lineBD<-paste("95% CI: [",round(100/(1+exp(-res$lower.random)),digits=1) ,"%, ",
              round(100/(1+exp(-res$upper.random)),digits=1) ,"%], I2=",
              (round(res$I2*100)),"%, ",
              "tau2=",(round(res$tau2,digits=2)),sep="")

#p-value for comparison North vs South America
res0<-metaprop(event=round(n.i),n=round(n),data=igg0[igg0$region!="Central America",],
              subgroup=region,
              sm="PLOGIT",method="glmm",hakn=T)
res0

#order according to test within country
aux<-unique(igg0$country)
for(i in 1: length(aux)){
  wh<-which(igg0$country==aux[i])
  aa<-sort(igg0$test[wh],index.return=T)
  igg0[wh,]<-igg0[wh[aa$ix],]
}

#plot with pooling
tabletext <- cbind(
  c( "Country",igg0$country,"Pooled"),
  c("p",paste(round(igg0$mean,digits=1),"%"),paste(round(mBD,digits=1),"%")),
  c( "n_i/n", paste(igg0$n.i,"/",igg0$n),""),
  c("Ref.",refs[igg0$paper,1],""),
  c("Test",igg0$test,lineBD))


tiff(filename="iggBD.tiff",width=16*300,height=12*300,res=300,compression="lzw")
forestplot(tabletext, 
           graph.pos = 4,
           mean=c(NA,igg0$mean,mBD),
           lower=c(NA,igg0$lower,loBD),
           upper=c(NA,igg0$upper,upBD),
           is.summary = c(TRUE,rep(FALSE,nrow(igg0)),TRUE),
           txt_gp = fpTxtGp(label = list(gpar(fontfamily = "",cex=1.8),
                                         gpar(fontfamily = "",cex=1.8)),
                            ticks = gpar(fontfamily = "", cex = 1.8),
                            xlab  = gpar(fontfamily = "", cex = 1.8),
                            legend = gpar(fontfamily = "", cex = 1.8),
                            summary = gpar(fontfamily = "", cex = 1.8)),
           col=fpColors(lines="darkgray",zero="darkgray"),
           clip = c(0,45), 
           colgap=unit(0.02,"npc"),
           lwd.ci=c(3),
           lwd.zero=2,
           lty.ci=c(1),
           boxsize=0.45,
           xticks=seq(0,45,by=10),
           xlab="Percentage of IgG positive results [%]",
           graphwidth=unit(10,"cm"),
           title="IgG, blood donors",
           hrzl_lines=list("20"=gpar(lty=2,lwd=2,col="black"),
                           "21"=gpar(lty=2,lwd=2,col="black"),
                           "30"=gpar(lty=2,lwd=2,col="black"))
           
)
dev.off()

#sensitivity analysis BD
#one result at a time
selected_results<-"Zafrullah" # "Meng", "Zafrullah"
sel<-which(igg$analysed.in.group=="BD")
aux<-igg[sel,]
wh<-which(aux$research.group==selected_results & aux$overlap==0)
aux<-aux[-wh,]
aux[aux$research.group==selected_results,"overlap"]<-0

res1<-metaprop(event=n.i,n=n,data=aux[aux$overlap==0,],subgroup=region,
               sm="PLOGIT",method="glmm",hakn=T)

paste("BD: p=",round(100/(1+exp(-res1$TE.random)),digits=1),"%, ",
      "95% CI: [",round(100/(1+exp(-res1$lower.random)),digits=1) ,"%, ",
      round(100/(1+exp(-res1$upper.random)),digits=1) ,"%], I2=",
      (round(res1$I2*100)),"%, ",
      "tau2=",(round(res1$tau2,digits=2)),sep="")

wh<-which(res1$bylevs=="North America")
wh2<-which(res1$bylevs=="South America")
paste("NA: p=",round(100/(1+exp(-res1$TE.random.w[wh])),digits=1),"%, ",
      "95% CI: [",round(100/(1+exp(-res1$lower.random.w[wh])),digits=1) ,"%, ",
      round(100/(1+exp(-res1$upper.random.w[wh])),digits=1) ,"%], I2=",
      (round(res1$I2.w[wh]*100)),"%, ",
      "tau2=",(round(res1$tau2.w[wh],digits=2)),sep="")
#p-value comparing North and South America
1-pchisq(diff(res1$TE.random.w[c(wh,wh2)])^2/sum(res1$seTE.random.w[c(wh,wh2)]^2),1)

#all at the same time
sel<-which(igg$analysed.in.group=="BD")
aux<-igg[sel,]
wh<-which((aux$research.group=="Meng" |  aux$research.group=="Zafrullah") 
          & aux$overlap==0)
aux<-aux[-wh,]
aux[aux$research.group=="Meng" |  aux$research.group=="Zafrullah","overlap"]<-0

res1<-metaprop(event=n.i,n=n,data=aux[aux$overlap==0,],subgroup=region,
               sm="PLOGIT",method="glmm",hakn=T)

paste("BD: p=",round(100/(1+exp(-res1$TE.random)),digits=1),"%, ",
      "95% CI: [",round(100/(1+exp(-res1$lower.random)),digits=1) ,"%, ",
      round(100/(1+exp(-res1$upper.random)),digits=1) ,"%], I2=",
      (round(res1$I2*100)),"%, ",
      "tau2=",(round(res1$tau2,digits=2)),sep="")

wh<-which(res1$bylevs=="North America")
wh2<-which(res1$bylevs=="South America")
paste("NA: p=",round(100/(1+exp(-res1$TE.random.w[wh])),digits=1),"%, ",
      "95% CI: [",round(100/(1+exp(-res1$lower.random.w[wh])),digits=1) ,"%, ",
      round(100/(1+exp(-res1$upper.random.w[wh])),digits=1) ,"%], I2=",
      (round(res1$I2.w[wh]*100)),"%, ",
      "tau2=",(round(res1$tau2.w[wh],digits=2)),sep="")
#p-value comparing North and South America
1-pchisq(diff(res1$TE.random.w[c(wh,wh2)])^2/sum(res1$seTE.random.w[c(wh,wh2)]^2),1)



#general population with pooling
sel<-which(igg$overlap!=1 &
             igg$analysed.in.group=="GP")

igg0<-igg[sel,]
#sort according to region
wh1<-which(igg0$region=="South America")
wh2<-which(igg0$region=="Central America")
wh3<-which(igg0$region=="North America")
igg0<-igg0[c(wh1,wh2,wh3),]

res<-metaprop(event=round(n.i),n=round(n),data=igg0,
               subgroup=region,
               sm="PLOGIT",method="glmm",hakn=T)

mGP<-100/(1+exp(-res$TE.random))
loGP<-100/(1+exp(-res$lower.random))
upGP<-100/(1+exp(-res$upper.random))
lineGP<-paste("95% CI: [",round(100/(1+exp(-res$lower.random)),digits=1) ,"%, ",
              round(100/(1+exp(-res$upper.random)),digits=1) ,"%], I2=",
              (round(res$I2*100)),"%, ",
              "tau2=",(round(res$tau2,digits=2)),sep="")
#order according to test within country
aux<-unique(igg0$country)
for(i in 1: length(aux)){
  wh<-which(igg0$country==aux[i])
  aa<-sort(igg0$test[wh],index.return=T)
  igg0[wh,]<-igg0[wh[aa$ix],]
}

#plot with pooling
tabletext <- cbind(
  c("Country",igg0$country,"Pooled"),
  c("p",paste(round(igg0$mean,digits=1),"%"),paste(round(mGP,digits=1),"%")),
  c( "n_i/n", paste(igg0$n.i,"/",igg0$n),""),
  c("Ref.",refs[igg0$paper,1],""),
  c("Details",igg0$details,lineGP),
  c("Test",igg0$test,""))


tiff(filename="iggGP.tiff",width=19*300,height=9*300,res=300,compression="lzw")
forestplot(tabletext, 
           graph.pos = 4,
           mean=c(NA,igg0$mean,mGP),
           lower=c(NA,igg0$lower,loGP),
           upper=c(NA,igg0$upper,upGP),
           is.summary = c(TRUE,rep(FALSE,nrow(igg0)),TRUE),
           txt_gp = fpTxtGp(label = list(gpar(fontfamily = "",cex=1.5),
                                         gpar(fontfamily = "",cex=1.5)),
                            ticks = gpar(fontfamily = "", cex = 1.5),
                            xlab  = gpar(fontfamily = "", cex = 1.5),
                            legend = gpar(fontfamily = "", cex = 1.5)),
           col=fpColors(lines="darkgray",zero="darkgray"),
           clip = c(0,45), 
           colgap=unit(0.02,"npc"),
           lwd.ci=c(3),
           lwd.zero=2,
           lty.ci=c(1),
           boxsize=0.45,
           xticks=seq(0,45,by=10),
           xlab="Percentage of IgG positive results [%]",
           graphwidth=unit(10,"cm"),
           title="IgG, general population",
           hrzl_lines=list("12"=gpar(lty=2,lwd=2,col="black"),
                           "15"=gpar(lty=2,lwd=2,col="black"),
                           "23"=gpar(lty=2,lwd=2,col="black"))
           
)
dev.off()

#viral hep with pooling
sel<-which(igg$overlap!=1 &
             igg$analysed.in.group=="VH")

igg0<-igg[sel,]
#sort according to region
wh1<-which(igg0$region=="South America")
wh2<-which(igg0$region=="Central America")
wh3<-which(igg0$region=="North America")
igg0<-igg0[c(wh1,wh2,wh3),]

res<-metaprop(event=round(n.i),n=round(n),data=igg0,
              #subgroup=region,
              sm="PLOGIT",method="glmm",hakn=T)
mVH<-100/(1+exp(-res$TE.random))
loVH<-100/(1+exp(-res$lower.random))
upVH<-100/(1+exp(-res$upper.random))
lineVH<-paste("95% CI: [",round(100/(1+exp(-res$lower.random)),digits=1) ,"%, ",
              round(100/(1+exp(-res$upper.random)),digits=1) ,"%], I2=",
              (round(res$I2*100)),"%, ",
              "tau2=",(round(res$tau2,digits=2)),sep="")

#p-value for comparison of North and South America
res1<-metaprop(event=n.i,n=n,data=igg0[igg0$region=="South America" |
                                        igg0$region=="North America",],subgroup=region,
               sm="PLOGIT",method="glmm",hakn=T)

#leave outbreak out
res2<-metaprop(event=n.i,n=n,data=igg0[!grepl("outbreak",igg0$details),],subgroup=region,
               sm="PLOGIT",method="glmm",hakn=T)
paste("p=",round(100/(1+exp(-res2$TE.random)),digits=1),"%, ",
      "95% CI: [",round(100/(1+exp(-res2$lower.random)),digits=1) ,"%, ",
      round(100/(1+exp(-res2$upper.random)),digits=1) ,"%], I2=",
      (round(res2$I2*100)),"%, ",
      "tau2=",(round(res2$tau2,digits=2)),sep="")

#sensitivity analysis
selected_results<-"Covarrubia"
sel<-which(igg$analysed.in.group=="VH")
aux<-igg[sel,]
wh<-which(aux$research.group==selected_results & aux$overlap==0)
aux<-aux[-wh,]
aux[aux$research.group==selected_results,"overlap"]<-0

res2<-metaprop(event=n.i,n=n,data=aux[aux$overlap==0,],
               sm="PLOGIT",method="glmm",hakn=T)
paste("p=",round(100/(1+exp(-res2$TE.random)),digits=1),"%, ",
      "95% CI: [",round(100/(1+exp(-res2$lower.random)),digits=1) ,"%, ",
      round(100/(1+exp(-res2$upper.random)),digits=1) ,"%], I2=",
      (round(res2$I2*100)),"%, ",
      "tau2=",(round(res2$tau2,digits=2)),sep="")
res2<-metaprop(event=n.i,n=n,data=aux[(aux$region=="South America" |
                                         aux$region=="North America" ) &
                                        aux$overlap==0,],subgroup=region,
               sm="PLOGIT",method="glmm",hakn=T)
res2



#order according to test within country
aux<-unique(igg0$country)
for(i in 1: length(aux)){
  wh<-which(igg0$country==aux[i])
  aa<-sort(igg0$test[wh],index.return=T)
  igg0[wh,]<-igg0[wh[aa$ix],]
}



#plot with pooling
tabletext <- cbind(
  c("Country",igg0$country,"Pooled"),
  c("p",paste(round(igg0$mean,digits=1),"%"),paste(round(mVH,digits=1),"%")),
  c( "n_i/n", paste(igg0$n.i,"/",igg0$n),""),
  c("Ref.",refs[igg0$paper,1],""),
  c("Details",igg0$details,lineVH),
  c("Test",igg0$test,""))


tiff(filename="iggVH.tiff",width=18*300,height=9.5*300,res=300,compression="lzw")
forestplot(tabletext, 
           graph.pos = 4,
           mean=c(NA,igg0$mean,mVH),
           lower=c(NA,igg0$lower,loVH),
           upper=c(NA,igg0$upper,upVH),
           is.summary = c(TRUE,rep(FALSE,nrow(igg0)),TRUE),
           txt_gp = fpTxtGp(label = list(gpar(fontfamily = "",cex=1.5),
                                         gpar(fontfamily = "",cex=1.5)),
                            ticks = gpar(fontfamily = "", cex = 1.5),
                            xlab  = gpar(fontfamily = "", cex = 1.5),
                            legend = gpar(fontfamily = "", cex = 1.5),
                            summary = gpar(fontfamily = "", cex = 1.5)),
           col=fpColors(lines="darkgray",zero="darkgray"),
           clip = c(0,45), 
           colgap=unit(0.02,"npc"),
           lwd.ci=c(3),
           lwd.zero=2,
           lty.ci=c(1),
           boxsize=0.45,
           xticks=seq(0,80,by=15),
           xlab="Percentage of IgG positive results [%]",
           graphwidth=unit(10,"cm"),
           title="IgG, viral hepatitis",
           hrzl_lines=list("17"=gpar(lty=2,lwd=2,col="black"),
                           "19"=gpar(lty=2,lwd=2,col="black"),
                           "23"=gpar(lty=2,lwd=2,col="black"))
           )
dev.off()


#immunodeficiency with pooling
#define I/C as I
igg$analysed.in.group0<-igg$analysed.in.group
igg$analysed.in.group0[igg$analysed.in.group0=="I/C"]<-"I"

sel<-which(igg$overlap!=1 &
             igg$analysed.in.group0=="I")

igg0<-igg[sel,]

aa<-sort(igg0$country,index.return=T)
igg0<-igg0[aa$ix,]

#sort according to region
wh1<-which(igg0$region=="South America")
wh2<-which(igg0$region=="Central America")
wh3<-which(igg0$region=="North America")
igg0<-igg0[c(wh1,wh2,wh3),]


res<-metaprop(event=round(n.i),n=round(n),data=igg0,
              sm="PLOGIT",method="glmm",hakn=T)

mI<-100/(1+exp(-res$TE.random))
loI<-100/(1+exp(-res$lower.random))
upI<-100/(1+exp(-res$upper.random))
lineI<-paste("95% CI: [",round(100/(1+exp(-res$lower.random)),digits=1) ,"%, ",
             round(100/(1+exp(-res$upper.random)),digits=1) ,"%], I2=",
             (round(res$I2*100)),"%, ",
             "tau2=",(round(res$tau2,digits=2)),sep="")

#p-value for comparison North vs South America
res1<-metaprop(event=n.i,n=n,data=igg0[igg0$region=="South America" |
                                         igg0$region=="North America",],subgroup=region,
               sm="PLOGIT",method="glmm",hakn=T)
res1

#alternatively using F-distribution when obtaining the p-value
#1-pf(diff(res1$TE.random.w)^2/sum(res1$seTE.random.w^2),1,sum(res1$k.w)-2)

#order according to test within country
aux<-unique(igg0$country)
for(i in 1: length(aux)){
  wh<-which(igg0$country==aux[i])
  aa<-sort(igg0$test[wh],index.return=T)
  igg0[wh,]<-igg0[wh[aa$ix],]
}

#plot with pooling
tabletext <- cbind(
  c("Country",igg0$country,"Pooled"),
  c("p",paste(round(igg0$mean,digits=1),"%"),paste(round(mI,digits=1),"%")),
  c( "n_i/n", paste(igg0$n.i,"/",igg0$n),""),
  c("Ref.",refs[igg0$paper,1],""),
  c("Details",igg0$details,lineI),
  c("Test",igg0$test,""))


tiff(filename="iggI.tiff",width=20*300,height=12*300,res=300,compression="lzw")
forestplot(tabletext, 
           graph.pos = 4,
           mean=c(NA,igg0$mean,mI),
           lower=c(NA,igg0$lower,loI),
           upper=c(NA,igg0$upper,upI),
           is.summary = c(TRUE,rep(FALSE,nrow(igg0)),TRUE),
           txt_gp = fpTxtGp(label = list(gpar(fontfamily = "",cex=1.8),
                                         gpar(fontfamily = "",cex=1.8)),
                            ticks = gpar(fontfamily = "", cex = 1.8),
                            xlab  = gpar(fontfamily = "", cex = 1.8),
                            legend = gpar(fontfamily = "", cex = 1.8),
                            summary = gpar(fontfamily = "", cex = 1.8)),
           col=fpColors(lines="darkgray",zero="darkgray"),
           clip = c(0,45), 
           colgap=unit(0.02,"npc"),
           lwd.ci=c(3),
           lwd.zero=2,
           lty.ci=c(1),
           boxsize=0.45,
           xticks=seq(0,60,by=15),
           xlab="Percentage of IgG positive results [%]",
           graphwidth=unit(10,"cm"),
           title="IgG, immunodeficiency",
           hrzl_lines=list("18"=gpar(lty=2,lwd=2,col="black"),
                           "19"=gpar(lty=2,lwd=2,col="black"),
                           "32"=gpar(lty=2,lwd=2,col="black"))
           
)
dev.off()


#PW, EG, C, OG
 sel<-which(igg$overlap!=1 &
             (igg$analysed.in.group=="PW" |
                igg$analysed.in.group=="C" |
                igg$analysed.in.group=="EG" |
                igg$analysed.in.group=="OG"  ))
#pooling
res<-metaprop(event=round(n.i),n=round(n),data=igg[sel,],subgroup=analysed.in.group,
              sm="PLOGIT",method="glmm",hakn=T)

#extract pooled estimates for the different subgroups
pooled<-data.frame(m=rep(NA,4),
                   lo=rep(NA,4),
                   up=rep(NA,4),
                   line=rep(" ",4))
row.names(pooled)<-c("PW","EG","OG","C")
for(i in 1: nrow(pooled)){
  wh<-which(res$bylevs==row.names(pooled)[i])
  pooled[i,"m"]<-100/(1+exp(-res$TE.random.w[wh]))
  pooled[i,"lo"]<-100/(1+exp(-res$lower.random.w[wh]))
  pooled[i,"up"]<-100/(1+exp(-res$upper.random.w[wh]))
  pooled[i,"line"]<-paste("95% CI: [",round(100/(1+exp(-res$lower.random.w[wh])),digits=1) ,"%, ",
                          round(100/(1+exp(-res$upper.random.w[wh])),digits=1) ,"%], I2=",
                          (round(res$I2.w[wh]*100)),"%, ",
                          "tau2=",(round(res$tau2.w[wh],digits=2)),sep="")
}

#forest plot
igg0<-igg[sel,]
order1<-c("PW","EG","OG","C")
mmean<-NA
llo<-NA
uup<-NA
hrz_lines_ind<-NULL
tabletext<-cbind("Category","p","n_i/n","Ref.","Country","Details","Test")
for (i in 1: length(order1)){
  wh<-which(row.names(pooled)==order1[i])
  wh1<-which(igg0$analysed.in.group==order1[i])
  if (length(wh)>0){
    tabletext<-rbind(tabletext,
                     cbind(
                       c(dict[igg0$analysed.in.group[wh1],1],"Random-effects GLMM"),
                       c(paste(round(igg0$mean[wh1],digits=1),"%"),
                         paste(round(pooled[wh,"m"],digits=1),"%")),
                       c(paste(igg0$n.i[wh1],"/",igg0$n[wh1])," "),
                       c(refs[igg0$paper[wh1],1],""),
                       c(igg0$country[wh1],""),
                       c(igg0$details[wh1],pooled[wh,"line"]),
                       c(igg0$test[wh1],""))
    )
    mmean<-c(mmean,igg0$mean[wh1],pooled[wh,"m"])
    llo<-c(llo,igg0$lower[wh1],pooled[wh,"lo"])
    uup<-c(uup,igg0$upper[wh1],pooled[wh,"up"])
    
  }else{
    tabletext<-rbind(tabletext,
                     cbind(
                       c(dict[igg0$analysed.in.group[wh1],1]),
                       c(paste(round(igg0$mean[wh1],digits=1),"%")),
                       c(paste(igg0$n.i[wh1],"/",igg0$n[wh1])),
                       c(refs[igg0$paper[wh1],1]),
                       c(igg0$country[wh1]),
                       c(igg0$details[wh1]),
                       c(igg0$test[wh1]))
    )
    mmean<-c(mmean,igg0$mean[wh1])
    llo<-c(llo,igg0$lower[wh1])
    uup<-c(uup,igg0$upper[wh1])
  }
  hrz_lines_ind<-c(hrz_lines_ind,nrow(tabletext))
}


summaryInd<-c(tabletext[,1]=="Random-effects GLMM")
summaryInd[1]<-TRUE

hrz_lines<-vector("list",length(hrz_lines_ind)-1)
names(hrz_lines)<-as.character(hrz_lines_ind[1:(length(hrz_lines_ind)-1)]+1)
for (i in 1: length(hrz_lines)){
  hrz_lines[[i]]<-gpar(lty=2,lwd=2,col="black")
}

tiff(filename="iggPW_C_EG_OG.tiff",width=26.5*300,height=14.5*300,res=300,compression="lzw")
forestplot(tabletext, 
           graph.pos = 4,
           mean=mmean,
           lower=llo,
           upper=uup,
           is.summary = summaryInd,
           txt_gp = fpTxtGp(label = list(gpar(fontfamily = "",cex=2),
                                         gpar(fontfamily = "",cex=2)),
                            ticks = gpar(fontfamily = "", cex = 2),
                            xlab  = gpar(fontfamily = "", cex = 2),
                            legend = gpar(fontfamily = "", cex = 2),
                            summary = gpar(fontfamily = "", cex = 2)),
           col=fpColors(lines="darkgray",zero="darkgray"),
           clip = c(0,45), 
           colgap=unit(0.01,"npc"),
           lwd.ci=c(4),
           lwd.zero=3,
           lty.ci=c(1),
           boxsize=0.45,
           xticks=seq(0,45,by=10),
           lwd.xaxis=2,
           xlab="Percentage of IgG positive results [%]",
           graphwidth=unit(10,"cm"),
           title="IgG",
           hrzl_lines=hrz_lines
           
)
dev.off()

#sensitivity analysis
sel<-which(igg$analysed.in.group=="PW" |
                igg$analysed.in.group=="C" |
                igg$analysed.in.group=="EG" |
                igg$analysed.in.group=="OG"  )
aux<-igg[sel,]
wh<-which((aux$research.group=="Remondegui" |  aux$research.group=="Martins") 
          & aux$overlap==0)
aux<-aux[-wh,]
aux[aux$research.group=="Remondegui" |  aux$research.group=="Martins","overlap"]<-0

res1<-metaprop(event=n.i,n=n,data=aux[aux$overlap==0,],subgroup=analysed.in.group,
               sm="PLOGIT",method="glmm",hakn=T)

wh<-which(res1$bylevs=="EG")
wh2<-which(res1$bylevs=="OG")
paste("EG: p=",round(100/(1+exp(-res1$TE.random.w[wh])),digits=1),"%, ",
      "95% CI: [",round(100/(1+exp(-res1$lower.random.w[wh])),digits=1) ,"%, ",
      round(100/(1+exp(-res1$upper.random.w[wh])),digits=1) ,"%], I2=",
      (round(res1$I2.w[wh]*100)),"%, ",
      "tau2=",(round(res1$tau2.w[wh],digits=2)),sep="")

paste("OG: p=",round(100/(1+exp(-res1$TE.random.w[wh2])),digits=1),"%, ",
      "95% CI: [",round(100/(1+exp(-res1$lower.random.w[wh2])),digits=1) ,"%, ",
      round(100/(1+exp(-res1$upper.random.w[wh2])),digits=1) ,"%], I2=",
      (round(res1$I2.w[wh2]*100)),"%, ",
      "tau2=",(round(res1$tau2.w[wh2],digits=2)),sep="")


# EP, PRE, R
sel<-which(igg$overlap!=1 &
             (igg$analysed.in.group=="EP" |
                igg$analysed.in.group=="PRE" |
                igg$analysed.in.group=="R"))
#pooling
res<-metaprop(event=round(n.i),n=round(n),data=igg[sel,],subgroup=analysed.in.group,
              sm="PLOGIT",method="glmm",hakn=T)

#extract pooled estimates for the different subgroups
pooled<-data.frame(m=rep(NA,3),
                   lo=rep(NA,3),
                   up=rep(NA,3),
                   line=rep(" ",3))
row.names(pooled)<-c("EP","PRE","R")
for(i in 1: nrow(pooled)){
  wh<-which(res$bylevs==row.names(pooled)[i])
  pooled[i,"m"]<-100/(1+exp(-res$TE.random.w[wh]))
  pooled[i,"lo"]<-100/(1+exp(-res$lower.random.w[wh]))
  pooled[i,"up"]<-100/(1+exp(-res$upper.random.w[wh]))
  pooled[i,"line"]<-paste("95% CI: [",round(100/(1+exp(-res$lower.random.w[wh])),digits=1) ,"%, ",
                          round(100/(1+exp(-res$upper.random.w[wh])),digits=1) ,"%], I2=",
                          (round(res$I2.w[wh]*100)),"%, ",
                          "tau2=",(round(res$tau2.w[wh],digits=2)),sep="")
}

#forest plot
igg0<-igg[sel,]
order1<-c("PRE","EP","R")
mmean<-NA
llo<-NA
uup<-NA
hrz_lines_ind<-NULL
tabletext<-cbind("Category","p","n_i/n","Ref.","Country","Details","Test")
for (i in 1: length(order1)){
  wh<-which(row.names(pooled)==order1[i])
  wh1<-which(igg0$analysed.in.group==order1[i])
  if (length(wh)>0){
    tabletext<-rbind(tabletext,
                     cbind(
                       c(dict[igg0$analysed.in.group[wh1],1],"Random-effects GLMM"),
                       c(paste(round(igg0$mean[wh1],digits=1),"%"),
                         paste(round(pooled[wh,"m"],digits=1),"%")),
                       c(paste(igg0$n.i[wh1],"/",igg0$n[wh1])," "),
                       c(refs[igg0$paper[wh1],1],""),
                       c(igg0$country[wh1],""),
                       c(igg0$details[wh1],pooled[wh,"line"]),
                       c(igg0$test[wh1],""))
    )
    mmean<-c(mmean,igg0$mean[wh1],pooled[wh,"m"])
    llo<-c(llo,igg0$lower[wh1],pooled[wh,"lo"])
    uup<-c(uup,igg0$upper[wh1],pooled[wh,"up"])
    
  }else{
    tabletext<-rbind(tabletext,
                     cbind(
                       c(dict[igg0$analysed.in.group[wh1],1]),
                       c(paste(round(igg0$mean[wh1],digits=1),"%")),
                       c(paste(igg0$n.i[wh1],"/",igg0$n[wh1])),
                       c(refs[igg0$paper[wh1],1]),
                       c(igg0$country[wh1]),
                       c(igg0$details[wh1]),
                       c(igg0$test[wh1]))
    )
    mmean<-c(mmean,igg0$mean[wh1])
    llo<-c(llo,igg0$lower[wh1])
    uup<-c(uup,igg0$upper[wh1])
  }
  hrz_lines_ind<-c(hrz_lines_ind,nrow(tabletext))
}


summaryInd<-c(tabletext[,1]=="Random-effects GLMM")
summaryInd[1]<-TRUE

hrz_lines<-vector("list",length(hrz_lines_ind)-1)
names(hrz_lines)<-as.character(hrz_lines_ind[1:(length(hrz_lines_ind)-1)]+1)
for (i in 1: length(hrz_lines)){
  hrz_lines[[i]]<-gpar(lty=2,lwd=2,col="black")
}

tiff(filename="iggPRE_EP_R.tiff",width=24.5*300,height=14.5*300,res=300,compression="lzw")
forestplot(tabletext, 
           graph.pos = 4,
           mean=mmean,
           lower=llo,
           upper=uup,
           is.summary = summaryInd,
           txt_gp = fpTxtGp(label = list(gpar(fontfamily = "",cex=2),
                                         gpar(fontfamily = "",cex=2)),
                            ticks = gpar(fontfamily = "", cex = 2),
                            xlab  = gpar(fontfamily = "", cex = 2),
                            legend = gpar(fontfamily = "", cex = 2),
                            summary = gpar(fontfamily = "", cex = 2)),
           col=fpColors(lines="darkgray",zero="darkgray"),
           clip = c(0,45), 
           colgap=unit(0.01,"npc"),
           lwd.ci=c(4),
           lwd.zero=3,
           lwd.xaxis=2,
           lty.ci=c(1),
           boxsize=0.45,
           xticks=seq(0,80,by=15),
           xlab="Percentage of IgG positive results [%]",
           graphwidth=unit(10,"cm"),
           title="IgG",
           hrzl_lines=hrz_lines
)
dev.off()

#sensitivity
sel<-which(igg$analysed.in.group=="EP" |
             igg$analysed.in.group=="PRE" |
             igg$analysed.in.group=="R")
aux<-igg[sel,]
aux[aux$overlap==1,]
#one result exchanged at a time (each subgroup considered separately)
selected_results<-c("Meng","Freitas") # c("Meng","Freitas") or c("Engle","Campolmi")
aux<-igg[sel,]
wh<-which((aux$research.group==selected_results[1] |  
             aux$research.group==selected_results[2]) 
          & aux$overlap==0)
aux<-aux[-wh,]
aux[aux$research.group==selected_results[1] |  
      aux$research.group==selected_results[2],"overlap"]<-0

res1<-metaprop(event=round(n.i),n=round(n),data=aux[aux$overlap==0,],
               subgroup=analysed.in.group,
               sm="PLOGIT",method="glmm",hakn=T)
wh<-which(res1$bylevs=="PRE")
wh2<-which(res1$bylevs=="R")
paste("PRE: p=",round(100/(1+exp(-res1$TE.random.w[wh])),digits=1),"%, ",
      "95% CI: [",round(100/(1+exp(-res1$lower.random.w[wh])),digits=1) ,"%, ",
      round(100/(1+exp(-res1$upper.random.w[wh])),digits=1) ,"%], I2=",
      (round(res1$I2.w[wh]*100)),"%, ",
      "tau2=",(round(res1$tau2.w[wh],digits=2)),sep="")

paste("R: p=",round(100/(1+exp(-res1$TE.random.w[wh2])),digits=1),"%, ",
      "95% CI: [",round(100/(1+exp(-res1$lower.random.w[wh2])),digits=1) ,"%, ",
      round(100/(1+exp(-res1$upper.random.w[wh2])),digits=1) ,"%], I2=",
      (round(res1$I2.w[wh2]*100)),"%, ",
      "tau2=",(round(res1$tau2.w[wh2],digits=2)),sep="")

#all at once
aux<-igg[sel,]
wh<-which((aux$research.group=="Meng" |
             aux$research.group=="Engle" |
             aux$research.group=="Freitas" |
             aux$research.group=="Campolmi") 
          & aux$overlap==0)
aux<-aux[-wh,]
aux[aux$research.group=="Meng" |
      aux$research.group=="Engle" |
      aux$research.group=="Freitas" |
      aux$research.group=="Campolmi","overlap"]<-0

res1<-metaprop(event=round(n.i),n=round(n),data=aux[aux$overlap==0,],
               subgroup=analysed.in.group,
               sm="PLOGIT",method="glmm",hakn=T)
wh<-which(res1$bylevs=="PRE")
wh2<-which(res1$bylevs=="R")
paste("PRE: p=",round(100/(1+exp(-res1$TE.random.w[wh])),digits=1),"%, ",
      "95% CI: [",round(100/(1+exp(-res1$lower.random.w[wh])),digits=1) ,"%, ",
      round(100/(1+exp(-res1$upper.random.w[wh])),digits=1) ,"%], I2=",
      (round(res1$I2.w[wh]*100)),"%, ",
      "tau2=",(round(res1$tau2.w[wh],digits=2)),sep="")

paste("R: p=",round(100/(1+exp(-res1$TE.random.w[wh2])),digits=1),"%, ",
      "95% CI: [",round(100/(1+exp(-res1$lower.random.w[wh2])),digits=1) ,"%, ",
      round(100/(1+exp(-res1$upper.random.w[wh2])),digits=1) ,"%], I2=",
      (round(res1$I2.w[wh2]*100)),"%, ",
      "tau2=",(round(res1$tau2.w[wh2],digits=2)),sep="")

#without outlying seroprevalence
sel<-which(igg$overlap!=1 &
             (igg$analysed.in.group=="EP" |
                igg$analysed.in.group=="PRE" |
                igg$analysed.in.group=="R"))

wh<-which(!grepl("homeless",igg$details[sel]))
res1<-metaprop(event=round(n.i),n=round(n),data=igg[sel[wh],],subgroup=analysed.in.group,
               sm="PLOGIT",method="glmm",hakn=T)
res1



#pairwise comparisons to GP
#GP PRE
sel<-which(igg$overlap!=1 &
             (igg$analysed.in.group=="GP" |
                igg$analysed.in.group=="PRE"  ))
res<-metaprop(event=round(n.i),n=round(n),data=igg[sel,],subgroup=analysed.in.group,
              sm="PLOGIT",method="glmm",hakn=T)
res
#alternative p-value using F-quantiles
#1-pf(diff(res$TE.random.w)^2/sum(res$seTE.random.w^2),1,sum(res$k.w)-2)
#sensitivity
sel<-which((igg$analysed.in.group=="GP" |
                igg$analysed.in.group=="PRE"  ))
aux<-igg[sel,]
wh<-which((aux$research.group=="Meng" |
             aux$research.group=="Engle") 
          & aux$overlap==0)
aux<-aux[-wh,]
aux[aux$research.group=="Meng" |
      aux$research.group=="Engle" ,"overlap"]<-0
res1<-metaprop(event=round(n.i),n=round(n),data=aux[aux$overlap==0,],
               subgroup=analysed.in.group,
              sm="PLOGIT",method="glmm",hakn=T)
res1
#1-pf(diff(res1$TE.random.w)^2/sum(res1$seTE.random.w^2),1,sum(res1$k.w)-2)

selected_results<-"Meng" #"Meng", "Engle"
aux<-igg[sel,]
wh<-which((aux$research.group==selected_results) 
          & aux$overlap==0)
aux<-aux[-wh,]
aux[aux$research.group==selected_results,"overlap"]<-0
res1<-metaprop(event=round(n.i),n=round(n),data=aux[aux$overlap==0,],
               subgroup=analysed.in.group,
               sm="PLOGIT",method="glmm",hakn=T)
res1

#GP C
sel<-which(igg$overlap!=1 &
             (igg$analysed.in.group=="GP" |
                igg$analysed.in.group=="C"  ))
res<-metaprop(event=round(n.i),n=round(n),data=igg[sel,],subgroup=analysed.in.group,
              sm="PLOGIT",method="glmm",hakn=T)
res
#alternative p-value using F-quantiles
#1-pf(diff(res$TE.random.w)^2/sum(res$seTE.random.w^2),1,sum(res$k.w)-2)


######big overview##########
sel<-which(igg$overlap!=1)

res<-metaprop(event=round(n.i),n=round(n),data=igg[sel,],subgroup=analysed.in.group0,
              sm="PLOGIT",method="glmm",hakn=T)

aux1<-res$bylevs
aux<-sort(res$TE.random.w,index.return=T)
aux1<-aux1[aux$ix]
resAll<-data.frame(category =dict[aux1,1],
                   n= res$k.w[aux$ix],
                   p= 100/(1+exp(-res$TE.random.w[aux$ix])),
                     lower=100/(1+exp(-res$lower.random.w[aux$ix])),
                     upper=100/(1+exp(-res$upper.random.w[aux$ix])),
                     I2=round(res$I2.w[aux$ix]*100),
                     tau2=round(res$tau2.w[aux$ix],digits=2))

res<-metaprop(event=round(n.i),n=round(n),data=igg[sel,],subgroup=region,
              sm="PLOGIT",method="glmm",hakn=T)

aux1<-c(which(res$bylevs=="North America"),
       which(res$bylevs=="Central America"),
       which(res$bylevs=="South America"))
resAll1<-data.frame(category =c("North America","Central America/Caribbean",
                                "South America"),
                    n= res$k.w[aux1],
                    p= 100/(1+exp(-res$TE.random.w[aux1])),
                    lower=100/(1+exp(-res$lower.random.w[aux1])),
                    upper=100/(1+exp(-res$upper.random.w[aux1])),
                    I2=round(res$I2.w[aux1]*100),
                    tau2=round(res$tau2.w[aux1],digits=2))

#Central America without outbreak in Cuba 
sel1<-which(igg$overlap!=1 & !grepl("outbreak",igg[,"details"]))
res1<-metaprop(event=round(n.i),n=round(n),
               data=igg[sel1,],
               subgroup=region,
               sm="PLOGIT",method="glmm",hakn=T)
aux1<-which(res1$bylevs=="Central America")
data.frame(category ="Central America/Caribbean",
           n= res1$k.w[aux1],
           p= 100/(1+exp(-res1$TE.random.w[aux1])),
           lower=100/(1+exp(-res1$lower.random.w[aux1])),
           upper=100/(1+exp(-res1$upper.random.w[aux1])),
           I2=round(res1$I2.w[aux1]*100),
           tau2=round(res1$tau2.w[aux1],digits=2))


res<-metaprop(event=round(n.i),n=round(n),data=igg[sel,],subgroup=country,
              sm="PLOGIT",method="glmm",hakn=T)


aux<-c(unique(igg$country[igg$region=="North America"]),
       unique(igg$country[igg$region=="Central America"]),
       unique(igg$country[igg$region=="South America"]))
aux1<-which(res$bylevs==aux[1])
for (i in 2:length(aux)){
  aux1<-c(aux1,which(res$bylevs==aux[i]))
}
wh<-which(res$k.w[aux1]==1)
aux<-aux[-wh]
aux1<-aux1[-wh]

resAll2<-data.frame(category =aux,
                    n= res$k.w[aux1],
                    p= 100/(1+exp(-res$TE.random.w[aux1])),
                    lower=100/(1+exp(-res$lower.random.w[aux1])),
                    upper=100/(1+exp(-res$upper.random.w[aux1])),
                    I2=round(res$I2.w[aux1]*100),
                    tau2=round(res$tau2.w[aux1],digits=2))

#Cuba without outbreak
sel1<-which(igg$overlap!=1 & !grepl("outbreak",igg[,"details"]))
res1<-metaprop(event=round(n.i),n=round(n),
               data=igg[sel1,],
               subgroup=country,
               sm="PLOGIT",method="glmm",hakn=T)
aux1<-which(res1$bylevs=="Cuba")
data.frame(category ="Cuba",
           n= res1$k.w[aux1],
           p= 100/(1+exp(-res1$TE.random.w[aux1])),
           lower=100/(1+exp(-res1$lower.random.w[aux1])),
           upper=100/(1+exp(-res1$upper.random.w[aux1])),
           I2=round(res1$I2.w[aux1]*100),
           tau2=round(res1$tau2.w[aux1],digits=2))



resAll<-rbind.data.frame(resAll,resAll1,resAll2)

tabletext <- cbind(
  c( "Category",resAll$category),
  c("N",resAll$n),
  c("p",paste(round(resAll$p,digits=1),"%")),
  
  c( "Details",paste("95% CI: [",round(resAll$lower,digits=1),"%, ",
                     round(resAll$upper,digits=1),"%], I2=",
                     resAll$I2,"%, tau2=",resAll$tau2)))

tiff(filename="iggoverview.tiff",width=15*300,height=11*300,res=300,compression="lzw")
forestplot(tabletext, 
           graph.pos = 4,
           mean=c(NA,resAll$p),
           lower=c(NA,resAll$lower),
           upper=c(NA,resAll$upper),
           is.summary = #c(TRUE,rep(FALSE,nrow(resAll))),
             c(TRUE,rep(FALSE,5),TRUE,rep(FALSE,18)),
           txt_gp = fpTxtGp(label = list(gpar(fontfamily = "",cex=1.5),
                                         gpar(fontfamily = "",cex=1.5)),
                            ticks = gpar(fontfamily = "", cex = 1.5),
                            xlab  = gpar(fontfamily = "", cex = 1.5),
                            legend = gpar(fontfamily = "", cex = 1.5),
                            summary = gpar(fontfamily = "",fontface=2, cex = 1.5)),
           col=fpColors(lines="darkgray",zero="darkgray"),
           fn.ci_sum=function(col,size,...){fpDrawCircleCI(clr.marker=col,clr.line=col,
                                                      size=0.45,...)},
           clip = c(0,45), 
           colgap=unit(0.02,"npc"),
           lwd.ci=c(3),
           lwd.zero=2,
           lty.ci=c(1),
           boxsize=0.45,
           xticks=seq(0,35,by=5),
           xlab="Percentage of IgG positive results [%]",
           graphwidth=unit(10,"cm"),
           title="Pooled IgG seroprevalences",
           hrzl_lines=list("13"=gpar(lty=2,lwd=2,col="black"),
                           "16"=gpar(lty=2,lwd=2,col="black")
           )
           
           
)
dev.off()

#sensitivity analysis - region, country
#check that there is max one alternative result per sample
igg[igg$overlap==1,c("research.group","analysed.in.group")]

chosen<-"region" # "region","country
whcountry<-unique(igg[which(igg$overlap==1),chosen])

sensres<-data.frame(category=NULL,
                    n=NULL,
                    p=NULL,
                    lower=NULL,
                    upper=NULL,
                    I2=NULL,
                    tau2=NULL
                    )
k<-1
for (i in 1: length(whcountry)){
  igg0<-igg[igg[,chosen]==whcountry[i],]
  whaut_group<-igg0[igg0$overlap==1,c("research.group","analysed.in.group")]
  for (j in 1: nrow(whaut_group)){
    aux<-igg0
    wh<-which(aux$research.group==whaut_group[j,1] & 
                aux$analysed.in.group==whaut_group[j,2]& aux$overlap==0)
    aux<-aux[-wh,]
    aux[aux$research.group==whaut_group[j,1] &
          aux$analysed.in.group==whaut_group[j,2],"overlap"]<-0
    res1<-metaprop(event=round(n.i),n=round(n),data=aux[aux$overlap==0,],
                   sm="PLOGIT",method="glmm",hakn=T)
    sensres[k,"category"]<-whcountry[i]
    sensres[k,"n"]<-res1$k
    sensres[k,"p"]<-100/(1+exp(-res1$TE.random))
    sensres[k,"lower"]<-100/(1+exp(-res1$lower.random))
    sensres[k,"upper"]<-100/(1+exp(-res1$upper.random))
    sensres[k,"I2"]<-round(res1$I2*100)
    sensres[k,"tau2"]<-round(res1$tau2,digits=2)
    k<-k+1
  }
  #all at once
  aux<-igg0
  wh<-NULL
  for (j in 1: nrow(whaut_group)){
    wh<-c(wh,which(aux$research.group==whaut_group[j,1] & 
                aux$analysed.in.group==whaut_group[j,2]& aux$overlap==0))
  }
  aux<-aux[-wh,]
  aux$overlap[aux$overlap==1]<-0
  res1<-metaprop(event=round(n.i),n=round(n),data=aux[aux$overlap==0,],
                 sm="PLOGIT",method="glmm",hakn=T)
  sensres[k,"category"]<-paste(whcountry[i],"-All")
  sensres[k,"n"]<-res1$k
  sensres[k,"p"]<-100/(1+exp(-res1$TE.random))
  sensres[k,"lower"]<-100/(1+exp(-res1$lower.random))
  sensres[k,"upper"]<-100/(1+exp(-res1$upper.random))
  sensres[k,"I2"]<-round(res1$I2*100)
  sensres[k,"tau2"]<-round(res1$tau2,digits=2)
  k<-k+1
}



#extra plots showing countries
sel<-which(igg$overlap!=1 & igg$country=="Brazil")
igg0<-igg[sel,]

order1<-c("BD","GP","PW","EG","OG","PRE","EP","C","R","I","VH")
#a simple check that no subgroup was left out in the list above
if (any(is.na(match(igg0$analysed.in.group,order1)))){
  print(paste("Subgroup left out:"))
  print(unique(igg0$analysed.in.group[is.na(match(igg0$analysed.in.group,order1))]))
}else{
  print("OK")
}

#reorder as desired (according to order1)  
ind<-NULL
for (i in 1: length(order1)){
  ind<-c(ind,which(igg0$analysed.in.group==order1[i]))
}
igg0<-igg0[ind,]

#order according to test within categories
aux<-unique(igg0$analysed.in.group)
for(i in 1: length(aux)){
  wh<-which(igg0$analysed.in.group==aux[i])
  aa<-sort(igg0$test[wh],index.return=T)
  igg0[wh,]<-igg0[wh[aa$ix],]
}


tabletext <- cbind(
  c("Category",dict[igg0$analysed.in.group,1]),
  c("p",paste(round(igg0$mean,digits=1),"%")),
  c( "n_i/n", paste(igg0$n.i,"/",igg0$n)),
  c("Ref.",refs[igg0$paper,1]),
  c("Details",igg0$details),
  c("Test",igg0$test))


tiff(filename="iggBrazil.tiff",width=23*300,height=17*300,res=300,compression="lzw")
forestplot(tabletext, 
           graph.pos = 4,
           mean=c(NA,igg0$mean),
           lower=c(NA,igg0$lower),
           upper=c(NA,igg0$upper),
           is.summary = c(TRUE,rep(FALSE,nrow(igg0))),
           txt_gp = fpTxtGp(label = list(gpar(fontfamily = "",cex=1.8),
                                         gpar(fontfamily = "",cex=1.8)),
                            ticks = gpar(fontfamily = "", cex = 1.8),
                            xlab  = gpar(fontfamily = "", cex = 1.8),
                            legend = gpar(fontfamily = "", cex = 1.8)),
           col=fpColors(lines="darkgray",zero="darkgray"),
           clip = c(0,45), 
           colgap=unit(0.02,"npc"),
           lwd.ci=c(3),
           lwd.zero=2,
           lty.ci=c(1),
           boxsize=0.45,
           xticks=seq(0,50,by=10),
           xlab="Percentage of IgG positive results [%]",
           graphwidth=unit(10,"cm"),
           title="IgG, Brazil",
           hrzl_lines=list("12"=gpar(lty=2,lwd=2,col="black"),
                           "15"=gpar(lty=2,lwd=2,col="black"),
                           "19"=gpar(lty=2,lwd=2,col="black"),
                           "21"=gpar(lty=2,lwd=2,col="black"),
                           "24"=gpar(lty=2,lwd=2,col="black"),
                           "26"=gpar(lty=2,lwd=2,col="black"),
                           "29"=gpar(lty=2,lwd=2,col="black"),
                           "30"=gpar(lty=2,lwd=2,col="black"),
                           "34"=gpar(lty=2,lwd=2,col="black"),
                           "43"=gpar(lty=2,lwd=2,col="black")
           )
           
)
dev.off()

#Wantai
sel<-which(igg$overlap==0 & igg$country=="Brazil" &
             igg$test=="Wantai")
res<-metaprop(event=round(n.i),n=round(n),data=igg[sel,],
              sm="PLOGIT",method="glmm",hakn=T)

#Abbott
sel<-which(igg$overlap==0 & igg$country=="Brazil" &
             igg$test=="Abbott Laboratories")
res<-metaprop(event=round(n.i),n=round(n),data=igg[sel,],
              sm="PLOGIT",method="glmm",hakn=T)





sel<-c(which(igg$overlap!=1 & igg$country=="Bolivia"),
      which(igg$overlap!=1 & igg$country=="Peru"),
      which(igg$overlap!=1 & igg$country=="Colombia"))

tabletext <- cbind(
  c("Country",igg$country[sel]),
  c("p",paste(round(igg$mean[sel],digits=1),"%")),
  c( "n_i/n", paste(igg$n.i[sel],"/",igg$n[sel])),
  c("Ref.",refs[igg$paper[sel],1]),
  c("Category",dict[igg$analysed.in.group[sel],1]),
  c("Test",igg$test[sel]))


tiff(filename="iggBolPeruColombia.tiff",width=15*300,height=8*300,res=300,compression="lzw")
forestplot(tabletext, 
           graph.pos = 4,
           mean=c(NA,igg$mean[sel]),
           lower=c(NA,igg$lower[sel]),
           upper=c(NA,igg$upper[sel]),
           is.summary = c(TRUE,rep(FALSE,nrow(igg[sel,]))),
           txt_gp = fpTxtGp(label = list(gpar(fontfamily = "",cex=1.5),
                                         gpar(fontfamily = "",cex=1.5)),
                            ticks = gpar(fontfamily = "", cex = 1.5),
                            xlab  = gpar(fontfamily = "", cex = 1.5),
                            legend = gpar(fontfamily = "", cex = 1.5)),
           col=fpColors(lines="darkgray",zero="darkgray"),
           clip = c(0,45), 
           colgap=unit(0.02,"npc"),
           lwd.ci=c(3),
           lwd.zero=2,
           lty.ci=c(1),
           boxsize=0.45,
           xticks=seq(0,80,by=15),
           xlab="Percentage of IgG positive results [%]",
           graphwidth=unit(10,"cm"),
           title="IgG",
           hrzl_lines=list("10"=gpar(lty=2,lwd=2,col="black"),
                           "15"=gpar(lty=2,lwd=2,col="black")
           )
           
)
dev.off()

###numbers
#number of studies, range, median, etc.
#number of studies
length(unique(igg$paper[igg$overlap==0]))
length(unique(igg$paper[igg$overlap==0 & igg$region=="North America"]))
length(unique(igg$paper[igg$overlap==0 & igg$region=="South America"]))
length(unique(igg$paper[igg$overlap==0 & igg$region=="Central America"]))
# number of results
length(igg$paper[igg$overlap==0])
#range
range((igg$mean[igg$overlap==0]))
#median
median((igg$mean[igg$overlap==0]))

table(igg[igg$overlap==0,"region"])
aggregate(igg[igg$overlap==0,"paper"],list(igg[igg$overlap==0,"country"]),
          FUN=function(x){length(unique(x))})


aggregate(igg[igg$overlap==0,"paper"],list(igg[igg$overlap==0,"region"]),
          FUN=function(x){length(unique(x))})

aggregate(igg[igg$overlap==0,"mean"],list(igg[igg$overlap==0,"region"]),
          FUN=range)


#stack bar plot, overview of number of results per subpopulation and country
library(ggplot2)
igg$analysed.in.group0<-igg$analysed.in.group
igg$analysed.in.group0[igg$analysed.in.group0=="I/C"]<-"I"
igg$analysed.in.group0<-factor(igg$analysed.in.group0,
                               levels=unique(igg$analysed.in.group0),
                               labels=dict[unique(igg$analysed.in.group0),1])

c25 <- c(
  "dodgerblue2", "#E31A1C", # red
  "green1",
  "#6A3D9A", # purple
  "#FF7F00", # orange
  "black", "gold1",
  "skyblue2", "#FB9A99", # lt pink
  "palegreen2",
  "#CAB2D6", # lt purple
  "#FDBF6F", # lt orange
  "gray70", "khaki2",
  "maroon", "orchid1", "deeppink1", "blue1", "steelblue4",
  "darkturquoise", "green4", "yellow4", "yellow3",
  #"darkorange4",
  "#FF7F00", "brown"
)
tiff(filename="country_subgroups.tiff",width=10*300,height=8*300,res=300,compression="lzw")
ggplot(data = igg[igg$overlap==0,], aes(x = country)) +
  geom_bar(aes(fill = analysed.in.group0)) +
  scale_fill_manual(values=c25[25:1], name = "Population group") +
  labs(x = "Country", y = "Number of meta-analysed results")+
  theme_classic()+
  theme(axis.text.x = element_text(angle = 55, vjust = 0.8,hjust=0.8,size=15),
        text=element_text(size=20),
        axis.ticks.length = unit(0.35, "cm"))
dev.off()


#funnel plots
igg$analysed.in.group0<-igg$analysed.in.group
igg$analysed.in.group0[igg$analysed.in.group0=="I/C"]<-"I"

sel<-which(igg$overlap==0 & igg$analysed.in.group0=="BD")

res<-metaprop(event=round(n.i),n=round(n),data=igg[sel,],
              sm="PLOGIT",method="glmm",hakn=T)
tiff(filename="funnelBD.tiff",width=4*300,height=4*300,res=300,compression="lzw")
funnel(res,fixed=FALSE, random=TRUE,cex=1.3,lwd=2)
title(main="Blood donors")
dev.off()

sel<-which(igg$overlap==0 & igg$analysed.in.group0=="GP")

res<-metaprop(event=round(n.i),n=round(n),data=igg[sel,],
              sm="PLOGIT",method="glmm",hakn=T)
tiff(filename="funnelGP.tiff",width=4*300,height=4*300,res=300,compression="lzw")
funnel(res,fixed=FALSE, random=TRUE,cex=1.3,lwd=2)
title(main="General population")
dev.off()

sel<-which(igg$overlap==0 & igg$analysed.in.group0=="VH")

res<-metaprop(event=round(n.i),n=round(n),data=igg[sel,],
              sm="PLOGIT",method="glmm",hakn=T)
tiff(filename="funnelVH.tiff",width=4*300,height=4*300,res=300,compression="lzw")
funnel(res,fixed=FALSE, random=TRUE,cex=1.3,lwd=2)
title(main="Viral hepatitis")
dev.off()

sel<-which(igg$overlap==0 & igg$analysed.in.group0=="I")

res<-metaprop(event=round(n.i),n=round(n),data=igg[sel,],
              sm="PLOGIT",method="glmm",hakn=T)
tiff(filename="funnelI.tiff",width=4*300,height=4*300,res=300,compression="lzw")
funnel(res,fixed=FALSE, random=TRUE,cex=1.3,lwd=2)
title(main="Immunodeficiency")
dev.off()