#Author: Barbora Kessel
#Affiliation: Helmholtz Centre for Infection Research, Braunschweig, Germany
#E-mail: barbora.kessel@helmholtz-hzi.de
#Last update: 2022-02-23 
#################################

#this code yields results about total anti-HEV positivity

#used libraries
library(forestplot)
library(binom)
library(meta)
#optional sensitivity analysis (later) requires lme4

#read in code book for assigning the correct reference number to each study, consistent
#with the Reference List in the Supplementary material

aux<-read.csv("code_book.csv")
refs<-as.matrix(aux[,2])
row.names(refs)<-aux[,1]

#read in the data
dat<-read.csv("overview_forest.csv")

#assign region to each study
dat$region<-"Central America"
dat$region[dat$country=="USA" | 
             dat$country=="Canada" |
             dat$country=="Greenland" |
             dat$country=="Mexico" |
             grepl("USA",dat$country)]<-"North America"
dat$region[dat$country=="Chile" | 
             dat$country=="Argentina" |
             dat$country=="Brazil" |
             dat$country=="Bolivia" | 
             dat$country=="Colombia" |
             dat$country=="Peru" |
             dat$country=="Venezuela" | 
             dat$country=="Uruguay" |
             dat$country=="French Guiana"]<-"South America"

#check that no country was forgotten (i.e. Central America contains correct countries)
unique(dat$country[dat$region=="Central America"])

#create a connection between abbreviations and long names for subgroups
dict<-cbind(c("Blood donors","Ethnic groups","Viral hepatitis","Children",
              "Pregnant women","Immunodeficiency","Exposed","Occupational group",
              "Ethnic groups","Rural","General population","Pig related exposure",
              "Immunodef./Children"))
row.names(dict)<-c("BD","EG","VH","C","PW","I","EP","OG","EG/GP","R","GP","PRE","I/C")


#select only entries from all data that relate to total anti-HEV
tanti<-dat[grepl("Tanti",dat$param) & !grepl("[+]",dat$param),]

#calculate seroprevalences and Agresti-Coulll 95% confidence intervals
#for each study (given number of positive samples and the sample size) in %,
#truncate the intervals to the permissible range 0-100
tanti$mean<-tanti$n.i/tanti$n*100
aux<-binom.agresti.coull(tanti$n.i, tanti$n)
tanti$lower<-pmax(0,aux$lower*100)
tanti$upper<-pmin(100,aux$upper*100)

#sort according to population subgroup
aux<-sort(tanti$analysed.in.group,index.return=T)
tanti<-tanti[aux$ix,]

#sort according to country within population subgroup
aux<-unique(tanti$analysed.in.group)
for(i in 1: length(aux)){
  wh<-which(tanti$analysed.in.group==aux[i])
  aa<-sort(tanti$country[wh],index.return=T)
  tanti[wh,]<-tanti[wh[aa$ix],]
}


#create the following order of the population subgroups (for plotting)
order1<-c("BD","GP","PW","EG/GP","EG","OG","PRE","EP","C","R","I")
#a simple check that no subgroup was left out in the list above
if (any(is.na(match(tanti$analysed.in.group,order1)))){
  print(paste("Subgroup left out:"))
  print(unique(tanti$analysed.in.group[is.na(match(tanti$analysed.in.group,order1))]))
}else{
  print("OK")
}

#reorder as desired (according to order1)  
ind<-NULL
for (i in 1: length(order1)){
  ind<-c(ind,which(tanti$analysed.in.group==order1[i]))
}
tanti<-tanti[ind,]

#pooling
#the study with EG/GP should be considered under EG
#only studies with unique samples (overlap==0)
tanti$analysed.in.group0<-tanti$analysed.in.group
tanti$analysed.in.group0[tanti$analysed.in.group0=="EG/GP"]<-"EG"

res<-metaprop(event=n.i,n=n,data=tanti[tanti$overlap==0,],subgroup=analysed.in.group0,
              sm="PLOGIT",method="glmm",hakn=T)

#extract pooled estimates for the different subroups
pooled<-data.frame(m=rep(NA,7),
                   lo=rep(NA,7),
                   up=rep(NA,7),
                   line=rep(" ",7))
row.names(pooled)<-c("BD","GP","EG","PRE","PW","OG","EP")
for(i in 1: nrow(pooled)){
  wh<-which(res$bylevs==row.names(pooled)[i])
  pooled[i,"m"]<-100/(1+exp(-res$TE.random.w[wh]))
  pooled[i,"lo"]<-100/(1+exp(-res$lower.random.w[wh]))
  pooled[i,"up"]<-100/(1+exp(-res$upper.random.w[wh]))
  pooled[i,"line"]<-paste("95% CI: [",round(100/(1+exp(-res$lower.random.w[wh])),digits=1) ,"%, ",
                          round(100/(1+exp(-res$upper.random.w[wh])),digits=1) ,"%], I2=",
                          (round(res$I2.w[wh]*100)),"%, ",
                          "tau2=",(round(res$tau2.w[wh],digits=2)),sep="")
}


#Mast - different test, BD subgroup is effected
aux<-tanti
wh<-which(aux$research.group=="Mast" & aux$overlap==0)
aux<-aux[-wh,]
aux[aux$research.group=="Mast","overlap"]<-0

res1<-metaprop(event=n.i,n=n,data=aux[aux$overlap==0,],subgroup=analysed.in.group0,
               sm="PLOGIT",method="glmm",hakn=T)
wh<-which(res1$bylevs=="BD")
paste("p=",100/(1+exp(-res1$TE.random.w[wh])),", lo=",
100/(1+exp(-res1$lower.random.w[wh])),", up=",100/(1+exp(-res1$upper.random.w[wh])))
paste("95% CI: [",round(100/(1+exp(-res1$lower.random.w[wh])),digits=1) ,"%, ",
              round(100/(1+exp(-res1$upper.random.w[wh])),digits=1) ,"%], I2=",
              (round(res1$I2.w[wh]*100)),"%, ",
              "tau2=",(round(res1$tau2.w[wh],digits=2)),sep="")


#forest plot
tanti0<-tanti[tanti$overlap==0,]
order1<-order1[-which(order1=="EG/GP")] #do not run repeatedly!!
mmean<-NA
llo<-NA
uup<-NA
hrz_lines_ind<-NULL
tabletext<-cbind("Category","p","n_i/n","Ref.","Country","Details","Test")
for (i in 1: length(order1)){
  wh<-which(row.names(pooled)==order1[i])
  wh1<-which(tanti0$analysed.in.group0==order1[i])
  if (length(wh)>0){
    tabletext<-rbind(tabletext,
                     cbind(
                       c(dict[tanti0$analysed.in.group[wh1],1],"Random-effects GLMM"),
                       c(paste(round(tanti0$mean[wh1],digits=1),"%"),
                         paste(round(pooled[wh,"m"],digits=1),"%")),
                       c(paste(tanti0$n.i[wh1],"/",tanti0$n[wh1])," "),
                       c(refs[tanti0$paper[wh1],1],""),
                       c(tanti0$country[wh1],""),
                       c(tanti0$details[wh1],pooled[wh,"line"]),
                       c(tanti0$test[wh1],""))
    )
    mmean<-c(mmean,tanti0$mean[wh1],pooled[wh,"m"])
    llo<-c(llo,tanti0$lower[wh1],pooled[wh,"lo"])
    uup<-c(uup,tanti0$upper[wh1],pooled[wh,"up"])
    
  }else{
    tabletext<-rbind(tabletext,
                     cbind(
                       c(dict[tanti0$analysed.in.group[wh1],1]),
                       c(paste(round(tanti0$mean[wh1],digits=1),"%")),
                       c(paste(tanti0$n.i[wh1],"/",tanti0$n[wh1])),
                       c(refs[tanti0$paper[wh1],1]),
                       c(tanti0$country[wh1]),
                       c(tanti0$details[wh1]),
                       c(tanti0$test[wh1]))
    )
    mmean<-c(mmean,tanti0$mean[wh1])
    llo<-c(llo,tanti0$lower[wh1])
    uup<-c(uup,tanti0$upper[wh1])
  }
  hrz_lines_ind<-c(hrz_lines_ind,nrow(tabletext))
}


summaryInd<-c(tabletext[,1]=="Random-effects GLMM")
summaryInd[1]<-TRUE

hrz_lines<-vector("list",length(hrz_lines_ind)-1)
names(hrz_lines)<-as.character(hrz_lines_ind[1:(length(hrz_lines_ind)-1)]+1)
for (i in 1: length(hrz_lines)){
  hrz_lines[[i]]<-gpar(lty=2,lwd=3,col="black")
}


tiff(filename="tanti_pooling.tiff",width=29*300,height=22*300,res=300,compression="lzw")
forestplot(tabletext, 
           graph.pos = 4,
           mean=mmean,
           lower=llo,
           upper=uup,
           is.summary = summaryInd,
           txt_gp = fpTxtGp(label = list(gpar(fontfamily = "",cex=2.3),
                                         gpar(fontfamily = "",cex=2.3)),
                            ticks = gpar(fontfamily = "", cex = 2.3),
                            xlab  = gpar(fontfamily = "", cex = 2.3),
                            legend = gpar(fontfamily = "", cex = 2.3),
                            summary=gpar(fontfamily = "", cex = 2.3)),
           col=fpColors(lines="darkgray",zero="darkgray"),
           clip = c(0,45), 
           colgap=unit(0.01,"npc"),
           lwd.ci=c(5),
           lwd.zero=3,
           lwd.xaxis=3,
           lty.ci=c(1),
           boxsize=0.65,
           xticks=seq(0,45,by=10),
           xlab="Percentage of total anti-HEV positive results [%]",
           graphwidth=unit(12,"cm"),
           title="Total anti-HEV",
           hrzl_lines=hrz_lines
)
dev.off()


#country-wise
tantiC<-tanti

aux<-sort(tantiC$region,index.return=T)
tantiC<-tantiC[aux$ix,]

#sort according to country within region
aux<-unique(tantiC$region)
for(i in 1: length(aux)){
  wh<-which(tantiC$region==aux[i])
  aa<-sort(tantiC$country[wh],index.return=T)
  tantiC[wh,]<-tantiC[wh[aa$ix],]
}


#sort according to category within country
aux<-unique(tantiC$country)
for(i in 1: length(aux)){
  wh<-which(tantiC$country==aux[i])
  aa<-sort(tantiC$analysed.in.group[wh],index.return=T)
  tantiC[wh,]<-tantiC[wh[aa$ix],]
}

#pooling
res<-metaprop(event=n.i,n=n,data=tantiC[tantiC$overlap==0,],subgroup=region,
                   sm="PLOGIT",method="glmm",hakn=T)

wh<-which(res$bylevs=="North America")
mNA<-100/(1+exp(-res$TE.random.w[wh]))
loNA<-100/(1+exp(-res$lower.random.w[wh]))
upNA<-100/(1+exp(-res$upper.random.w[wh]))
lineNA<-paste("95% CI: [",round(100/(1+exp(-res$lower.random.w[wh])),digits=1) ,"%, ",
              round(100/(1+exp(-res$upper.random.w[wh])),digits=1) ,"%], I2=",
              (round(res$I2.w[wh]*100)),"%, ",
              "tau2=",(round(res$tau2.w[wh],digits=2)),sep="")

wh<-which(res$bylevs=="South America")
mSA<-100/(1+exp(-res$TE.random.w[wh]))
loSA<-100/(1+exp(-res$lower.random.w[wh]))
upSA<-100/(1+exp(-res$upper.random.w[wh]))
lineSA<-paste("95% CI: [",round(100/(1+exp(-res$lower.random.w[wh])),digits=1) ,"%, ",
              round(100/(1+exp(-res$upper.random.w[wh])),digits=1) ,"%], I2=",
              (round(res$I2.w[wh]*100)),"%, ",
              "tau2=",(round(res$tau2.w[wh],digits=2)),sep="")

wh<-which(res$bylevs=="Central America")
mCA<-100/(1+exp(-res$TE.random.w[wh]))
loCA<-100/(1+exp(-res$lower.random.w[wh]))
upCA<-100/(1+exp(-res$upper.random.w[wh]))
lineCA<-paste("95% CI: [",round(100/(1+exp(-res$lower.random.w[wh])),digits=1) ,"%, ",
              round(100/(1+exp(-res$upper.random.w[wh])),digits=1) ,"%], I2=",
              (round(res$I2.w[wh]*100)),"%, ",
              "tau2=",(round(res$tau2.w[wh],digits=2)),sep="")


#sensitivity analysis
#Mast - different test, North America is effected
aux<-tantiC
wh<-which(aux$research.group=="Mast" & aux$overlap==0)
aux<-aux[-wh,]
aux[aux$research.group=="Mast","overlap"]<-0

res1<-metaprop(event=n.i,n=n,data=aux[aux$overlap==0,],subgroup=region,
              sm="PLOGIT",method="glmm",hakn=T)
wh<-which(res1$bylevs=="North America")
paste("p=",100/(1+exp(-res1$TE.random.w[wh])),", lo=",
100/(1+exp(-res1$lower.random.w[wh])),", up=",100/(1+exp(-res1$upper.random.w[wh])))
paste("95% CI: [",round(100/(1+exp(-res1$lower.random.w[wh])),digits=1) ,"%, ",
              round(100/(1+exp(-res1$upper.random.w[wh])),digits=1) ,"%], I2=",
              (round(res1$I2.w[wh]*100)),"%, ",
              "tau2=",(round(res1$tau2.w[wh],digits=2)),sep="")


#plot
sel<-which(tantiC$overlap==0)
tabletext <- cbind(
  c("Country",tantiC$country[sel],
    "Central America/Caribbean","North America",
    "South America"),
  
  c("p",paste(round(tantiC$mean[sel],digits=1),"%"),
    paste(round(mCA,digits=1),"%"),
    paste(round(mNA,digits=1),"%"),
    paste(round(mSA,digits=1),"%")),
  c( "n_i/n",paste(tantiC$n.i[sel],"/",tantiC$n[sel]),"","",""),
  c("Ref.",refs[tantiC$paper[sel],1],"","",""),
  c( "Category",dict[tantiC$analysed.in.group[sel],1],
     lineCA,lineNA,lineSA),
  c( "Test",tantiC$test[sel],"","",""))

tiff(filename="tantiC_pooling.tiff",width=30*300,height=20*300,res=300,compression="lzw")
forestplot(tabletext, 
           graph.pos = 4,
           mean=c(NA,tantiC$mean[sel],mCA,mNA,mSA),
           lower=c(NA,tantiC$lower[sel],loCA,loNA,loSA),
           upper=c(NA,tantiC$upper[sel],upCA,upNA,upSA),
           is.summary = c(TRUE,rep(FALSE,nrow(tantiC[sel,])),
                          rep(TRUE,3)),
           txt_gp = fpTxtGp(label = list(gpar(fontfamily = "",cex=2.5),
                                         gpar(fontfamily = "",cex=2.5)),
                            ticks = gpar(fontfamily = "", cex = 1.5),
                            xlab  = gpar(fontfamily = "", cex = 2.5),
                            legend = gpar(fontfamily = "", cex = 2.5),
                            summary = gpar(fontfamily = "", cex = 2.5)),
           col=fpColors(lines="darkgray",zero="darkgray"),
           clip = c(0,45), 
           colgap=unit(0.02,"npc"),
           lwd.ci=c(3),
           lwd.zero=2,
           lty.ci=c(1),
           boxsize=0.65,
           xticks=seq(0,45,by=10),
           xlab="Percentage of total anti-HEV positive results [%]",
           graphwidth=unit(10,"cm"),
           title="Total anti-HEV",
           hrzl_lines=list("7"=gpar(lty=2,lwd=2,col="black"),
                           "18"=gpar(lty=2,lwd=2,col="black"),
                           "39"=gpar(lty=2,lwd=2,col="black"))
           )
dev.off()

#extra random effect making results from the same paper potentially positively correlated

#identifier for the usual random variation per result
tantiC$id<-1:nrow(tantiC)

#pooling per region
chosen_region<-"Central" #"Central", "South", "North"
wh<-which(grepl(chosen_region,tantiC$region) & tantiC$overlap==0) 
sel<-wh

f1<-lme4::glmer(cbind(n.i,n-n.i)~
              1+(1|id)+(1|paper),data=tantiC[sel,],family="binomial")

#pooled stimate with t-quantiles based confidence intervals
data.frame(est=round(1/(1+exp(-lme4::fixef(f1))),digits=4),
           lo=round(1/(1+exp(-(lme4::fixef(f1)-qt(0.975,length(sel)-1)*
                                 sqrt(vcov(f1)[1,1])))),
                    digits=4),
           up=round(1/(1+exp(-(lme4::fixef(f1)+qt(0.975,length(sel)-1)*
                                 sqrt(vcov(f1)[1,1])))),
                    digits=4))
lme4::getME(f1,"theta")^2

######
#number of studies, range, median, etc.
#number of studies
length(unique(tanti$paper[tanti$overlap==0]))
length(unique(tanti$paper[tanti$overlap==0 & tanti$region=="North America"]))
length(unique(tanti$paper[tanti$overlap==0 & tanti$region=="South America"]))
length(unique(tanti$paper[tanti$overlap==0 & tanti$region=="Central America"]))
# number of results
length(tanti$paper[tanti$overlap==0])
#range
range((tanti$mean[tanti$overlap==0]))
#median
median((tanti$mean[tanti$overlap==0]))
